﻿/** @file types.h
  * @brief 本文件包含数据类型的宏定义、使用的指令集的定义等。
  */
#ifndef TYPES_H__
#define TYPES_H__

/** @cond **/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <immintrin.h>
#include <nmmintrin.h>
#include <xmmintrin.h>
#include <emmintrin.h>
#include <pmmintrin.h>
#include <tmmintrin.h>
#include <smmintrin.h>
#include <wmmintrin.h>
#include <limits.h>
#include <math.h>
/** @endcond **/

#ifdef __GNUC__
#include <sched.h>
#include <unistd.h>
#endif

typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned int u32;
typedef unsigned long long u64;

#define data_t u8

#endif //TYPES_H__
