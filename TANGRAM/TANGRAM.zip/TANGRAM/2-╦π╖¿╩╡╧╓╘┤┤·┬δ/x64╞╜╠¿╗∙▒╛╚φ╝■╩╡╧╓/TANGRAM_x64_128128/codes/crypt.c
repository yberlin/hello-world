﻿/** @file crypt.cpp
  * @brief 本文件包含TANGRAM密码算法的加密、解密函数定义。
  */
#include "tangram128128.h"

/** @brief 将变量  @a x 的第 @a n 个32-比特字取出 */
#  define word32_in(x,n)    (*((u32*)(x)+(n)))
/** @brief 将32-比特字 @a v 插入到变量 @a x 的第 @a n 个字的位置 */
#  define word32_out(x,n,v) (*((u32*)(x)+(n)) = (v))

/** @brief TANGRAM的ShiftRow的第1行的行移位参数 */
#define ROL32_1  1
/** @brief TANGRAM的ShiftRow的第2行的行移位参数 */
#define ROL32_2  8
/** @brief TANGRAM的ShiftRow的第3行的行移位参数 */
#define ROL32_3 11

/** @brief 从 @a ip 地址开始，将一个分组的第0、1、2、3个32-比特字依次装载到 @a x0, @a x1, @a x2, @a x3 中。
 *
 *  @param [ in] ip 一个16-字节分组在内存中的输入起始地址
 *  @param [out] x0 存放TANGRAM状态矩阵的第 0 行的寄存器
 *  @param [out] x1 存放TANGRAM状态矩阵的第 1 行的寄存器
 *  @param [out] x2 存放TANGRAM状态矩阵的第 2 行的寄存器
 *  @param [out] x3 存放TANGRAM状态矩阵的第 3 行的寄存器
 */
#define input_1Block(x0, x1, x2, x3, ip)                                                                                      \
{                                                                                                                             \
	x0 = word32_in(ip, 0);                                                                                                    \
	x1 = word32_in(ip, 1);                                                                                                    \
	x2 = word32_in(ip, 2);                                                                                                    \
	x3 = word32_in(ip, 3);                                                                                                    \
}
#define input_1Block_CBC(x0, x1, x2, x3, ip, pre)                                                                              \
{                                                                                                                             \
	x0 = word32_in(ip, 0)^word32_in(pre, 0);                                                                                   \
	x1 = word32_in(ip, 1)^word32_in(pre, 1);                                                                                   \
	x2 = word32_in(ip, 2)^word32_in(pre, 2);                                                                                   \
	x3 = word32_in(ip, 3)^word32_in(pre, 3);                                                                                   \
}


/** @brief 从 @a op 地址开始，将 @a x0, @a x1, @a x2, @a x3 依次装载到一个分组的第0、1、2、3个32-比特字中。
 *
 *  @param [ in] x0 存放TANGRAM状态矩阵的第 0 行的寄存器
 *  @param [ in] x1 存放TANGRAM状态矩阵的第 1 行的寄存器
 *  @param [ in] x2 存放TANGRAM状态矩阵的第 2 行的寄存器
 *  @param [ in] x3 存放TANGRAM状态矩阵的第 3 行的寄存器
 *  @param [out] op 一个16-字节分组在内存中的输出起始地址
 */
#define output_1Block(x0, x1, x2, x3, op)                                                                                     \
{                                                                                                                             \
	word32_out(op, 0, x0);                                                                                                    \
	word32_out(op, 1, x1);                                                                                                    \
	word32_out(op, 2, x2);                                                                                                    \
	word32_out(op, 3, x3);                                                                                                    \
};

#define output_1Block_CBC(x0, x1, x2, x3, op, pre)                                                                                     \
{                                                                                                                             \
	word32_out(op, 0, x0^word32_in(pre, 0));                                                                                                    \
	word32_out(op, 1, x1^word32_in(pre, 1));                                                                                                    \
	word32_out(op, 2, x2^word32_in(pre, 2));                                                                                                    \
	word32_out(op, 3, x3^word32_in(pre, 3));                                                                                                    \
}

/** @brief TANGRAM加密算法的S盒层（SubColumn）使用通用指令进行比特切片实现的指令序列。
 *
 *  这个指令序列由Gladman早在1998年优化实现Serpent的S盒指令执行序列时就公布的一个C语言程序生成。
 *  @see http://www.gladman.me.uk/
 * 
 *  @param [ in] a S盒第 0 个比特位置的输入，即TANGRAM密码状态的第 0 行作为输入
 *  @param [ in] b S盒第 1 个比特位置的输入，即TANGRAM密码状态的第 1 行作为输入
 *  @param [ in] c S盒第 2 个比特位置的输入，即TANGRAM密码状态的第 2 行作为输入
 *  @param [ in] d S盒第 3 个比特位置的输入，即TANGRAM密码状态的第 3 行作为输入
 *  @param [out] e S盒第 0 个比特位置的输出，即TANGRAM密码状态的第 0 行作为输出
 *  @param [out] f S盒第 1 个比特位置的输出，即TANGRAM密码状态的第 1 行作为输出
 *  @param [out] g S盒第 2 个比特位置的输出，即TANGRAM密码状态的第 2 行作为输出
 *  @param [out] h S盒第 3 个比特位置的输出，即TANGRAM密码状态的第 3 行作为输出
 */
#define forward_sbox_1Block(a, b, c, d, e, f, g, h)                                                                           \
{                                                                                                                             \
	t1 = a ^ c;                                                                                                               \
    t2 = a & b;                                                                                                               \
    t3 = d ^ t2;                                                                                                              \
    g = c ^ t3;                                                                                                               \
    t5 = b ^ c;                                                                                                               \
    t6 = t1 & t3;                                                                                                             \
    e = t5 ^ t6;                                                                                                              \
    t8 = b | d;                                                                                                               \
    t9 = t1 ^ t8;                                                                                                             \
    h = ~t9;                                                                                                                  \
    t11 = t5 & t9;                                                                                                            \
    f = t3 ^ t11;                                                                                                             \
}

/** @brief TANGRAM加密算法的P置换层（ShiftRow）使用通用指令进行比特切片实现的指令序列。
 *
 *  @param [in,out] x0 ShiftRow第 0 行的输入，并在原地执行循环左       0 位，得到第 0 行的输出
 *  @param [in,out] x1 ShiftRow第 1 行的输入，并在原地执行循环左 ROL32_1 位，得到第 1 行的输出
 *  @param [in,out] x2 ShiftRow第 2 行的输入，并在原地执行循环左 ROL32_2 位，得到第 2 行的输出
 *  @param [in,out] x3 ShiftRow第 3 行的输入，并在原地执行循环左 ROL32_3 位，得到第 3 行的输出
 */
#define forward_permutation_1Block(x0, x1, x2, x3)                                                                            \
	{                                                                                                                         \
	x1 = rol32(x1, ROL32_1);                                                                                                  \
	x2 = rol32(x2, ROL32_2);                                                                                                  \
	x3 = rol32(x3, ROL32_3);                                                                                                  \
};

/** @brief TANGRAM加密算法的轮密钥加（AddRoundKey）使用通用指令进行比特切片实现的指令序列。
 *
 *  @param [in,out] x0 TANGRAM状态矩阵的第 0 行，并在原地执行密钥加，得到第 0 行的输出
 *  @param [in,out] x1 TANGRAM状态矩阵的第 1 行，并在原地执行密钥加，得到第 1 行的输出
 *  @param [in,out] x2 TANGRAM状态矩阵的第 2 行，并在原地执行密钥加，得到第 2 行的输出
 *  @param [in,out] x3 TANGRAM状态矩阵的第 3 行，并在原地执行密钥加，得到第 3 行的输出
 *  @param [    in] kp 轮子密钥在内存中的起始地址
 */
#define forward_keyxor_1Block(x0, x1, x2, x3, kp)                                                                             \
	{                                                                                                                         \
	x0 ^= *(kp++);                                                                                                            \
	x1 ^= *(kp++);                                                                                                            \
	x2 ^= *(kp++);                                                                                                            \
	x3 ^= *(kp++);                                                                                                            \
}

/** @brief TANGRAM加密算法的轮函数使用通用指令，处理一个分组。
 *
 *  TANGRAM加密算法的轮函数是依次执行以下变换:
 *      - AddRoundKey   对应于forward_keyxor_1Block()
 *      - SubColumn     对应于forward_sbox_1Block()
 *      - ShiftRow      对应于forward_permutation_1Block()
 *
 *  @param [ in] a  一轮密码状态的第 0 行输入
 *  @param [ in] b  一轮密码状态的第 1 行输入
 *  @param [ in] c  一轮密码状态的第 2 行输入
 *  @param [ in] d  一轮密码状态的第 3 行输入
 *  @param [out] e  一轮密码状态的第 0 行输出
 *  @param [out] f  一轮密码状态的第 1 行输出
 *  @param [out] g  一轮密码状态的第 2 行输出
 *  @param [out] h  一轮密码状态的第 3 行输出
 *  @param [ in] kp 轮子密钥在内存中的起始地址
 */
#define forward_round_1Block(a, b, c, d, e, f, g, h, kp)                                                                      \
	{                                                                                                                         \
	forward_keyxor_1Block(a, b, c, d, kp);                                                                                    \
	forward_sbox_1Block(a, b, c, d, e, f, g, h);                                                                              \
	forward_permutation_1Block(e, f, g, h);                                                                                   \
}

/** @brief TANGRAM加密算法的最后一轮密钥加
 *
 *  TANGRAM加密算法的最后再次执行 AddRoundKey
 *
 *  @param [in,out] a  一轮密码状态的第 0 行输入，经过原地的与轮子密钥异或得到第 0 行输出
 *  @param [in,out] b  一轮密码状态的第 1 行输入，经过原地的与轮子密钥异或得到第 1 行输出
 *  @param [in,out] c  一轮密码状态的第 2 行输入，经过原地的与轮子密钥异或得到第 2 行输出
 *  @param [in,out] d  一轮密码状态的第 3 行输入，经过原地的与轮子密钥异或得到第 3 行输出
 *  @param [    in] kp 最后一轮子密钥在内存中的起始地址
 */
#define forward_last_round_1Block(a, b, c, d, kp)   forward_keyxor_1Block(a, b, c, d, kp);

/** @brief TANGRAM加密算法加密一个分组
 *
 *  TANGRAM加密算法共包含 44 个相同的轮函数（除轮密钥不同），以及最后一轮密钥加。
 *  考虑到x64平台指令缓存较大，本实现展开全部轮函数，避免变量的赋值。其中：
 *
 *  - @a r0  一轮密码状态的第 0 行输入（偶数轮）或输出（奇数轮）
 *  - @a r1  一轮密码状态的第 1 行输入（偶数轮）或输出（奇数轮）
 *  - @a r2  一轮密码状态的第 2 行输入（偶数轮）或输出（奇数轮）
 *  - @a r3  一轮密码状态的第 3 行输入（偶数轮）或输出（奇数轮）
 *  - @a r4  一轮密码状态的第 0 行输入（奇数轮）或输出（偶数轮）
 *  - @a r5  一轮密码状态的第 1 行输入（奇数轮）或输出（偶数轮）
 *  - @a r6  一轮密码状态的第 2 行输入（奇数轮）或输出（偶数轮）
 *  - @a r7  一轮密码状态的第 3 行输入（奇数轮）或输出（偶数轮）
 *  - @a in  输入分组的起始地址
 *  - @a out 输出分组的起始地址
 *  - @a kp  扩展密钥在内存中的起始地址
 */
#define encrypt_1Block                                                                               \
{																				                     \
	input_1Block(r0, r1, r2, r3, in);								                                 \
	for(i=0;i<44;i++){                                                                           \
	    forward_round_1Block(r0, r1, r2, r3, r4, r5, r6, r7, kp );                                   \
		r0=r4;r1=r5;r2=r6;r3=r7;                                                                     \
	}                                                                                                \
	forward_last_round_1Block(r0, r1, r2, r3, kp );			                                         \
	output_1Block(r0, r1, r2, r3, out);					                                             \
}
#define encrypt_1Block_CBC                                                                           \
{																				                     \
	input_1Block_CBC(r0, r1, r2, r3, in, preout);								                     \
	for(i=0;i<44;i++){                                                                           \
	    forward_round_1Block(r0, r1, r2, r3, r4, r5, r6, r7, kp );                                   \
		r0=r4;r1=r5;r2=r6;r3=r7;                                                                     \
	}                                                                                                \
	forward_last_round_1Block(r0, r1, r2, r3, kp );			                                         \
	output_1Block(r0, r1, r2, r3, out);					                                             \
}
/** @brief TANGRAM加密一个分组指定轮数
 *
 *  执行 @a rn 个相同的加密轮函数（除轮密钥不同），没有最后一轮密钥加。
 *  考虑到x64平台指令缓存较大，本实现 2 轮展开，避免变量的赋值。其中：
 *
 *  - @a r0  一轮密码状态的第 0 行输入（偶数轮）或输出（奇数轮）
 *  - @a r1  一轮密码状态的第 1 行输入（偶数轮）或输出（奇数轮）
 *  - @a r2  一轮密码状态的第 2 行输入（偶数轮）或输出（奇数轮）
 *  - @a r3  一轮密码状态的第 3 行输入（偶数轮）或输出（奇数轮）
 *  - @a r4  一轮密码状态的第 0 行输入（奇数轮）或输出（偶数轮）
 *  - @a r5  一轮密码状态的第 1 行输入（奇数轮）或输出（偶数轮）
 *  - @a r6  一轮密码状态的第 2 行输入（奇数轮）或输出（偶数轮）
 *  - @a r7  一轮密码状态的第 3 行输入（奇数轮）或输出（偶数轮）
 *  - @a in  输入分组的起始地址
 *  - @a out 输出分组的起始地址
 *  - @a kp  扩展密钥在内存中的起始地址
 */
#define encrypt_1Block_Round(rn)												          \
{																					      \
	input_1Block(r0, r1, r2, r3, in); 												      \
	for(i=0;i<rn;i++){                                                                \
	    forward_round_1Block(r0, r1, r2, r3, r4, r5, r6, r7, kp );                        \
		r0=r4;r1=r5;r2=r6;r3=r7;                                                          \
	}                                                                                     \
	forward_last_round_1Block(r0, r1, r2, r3, kp );			                              \
	output_1Block(r0, r1, r2, r3, out);					                                  \
}

/** @brief TANGRAM解密算法的S盒层（inverse SubColumn）使用通用指令进行比特切片实现的指令序列。
 *
 *  这个指令序列由Gladman早在1998年优化实现Serpent的S盒指令执行序列时就公布的一个C语言程序的扩展程序生成。
 *  我们在原来考虑的指令集 {xor, and, or, not} 的基础上加入 x64 平台具有的 andn 指令。Intel 编译器会自动将
 *  t3 = (~c) & a;这样的指令编译为 andn 指令。
 *
 *  @see http://www.gladman.me.uk/
 * 
 *  @param [ in] a 逆S盒第 0 个比特位置的输入，即TANGRAM密码状态的第 0 行作为输入
 *  @param [ in] b 逆S盒第 1 个比特位置的输入，即TANGRAM密码状态的第 1 行作为输入
 *  @param [ in] c 逆S盒第 2 个比特位置的输入，即TANGRAM密码状态的第 2 行作为输入
 *  @param [ in] d 逆S盒第 3 个比特位置的输入，即TANGRAM密码状态的第 3 行作为输入
 *  @param [out] e 逆S盒第 0 个比特位置的输出，即TANGRAM密码状态的第 0 行作为输出
 *  @param [out] f 逆S盒第 1 个比特位置的输出，即TANGRAM密码状态的第 1 行作为输出
 *  @param [out] g 逆S盒第 2 个比特位置的输出，即TANGRAM密码状态的第 2 行作为输出
 *  @param [out] h 逆S盒第 3 个比特位置的输出，即TANGRAM密码状态的第 3 行作为输出
 */
#define invert_sbox_1Block(a, b, c, d, e, f, g, h)                                                                            \
{                                                                                                                             \
	t1 = ~d;                                                                                                                  \
    t2 = a & t1;                                                                                                              \
    t3 = b ^ t2;                                                                                                              \
    g = c ^ t3;                                                                                                               \
    t5 = a ^ c;                                                                                                               \
    t6 = t1 & t3;                                                                                                             \
    f = t5 ^ t6;                                                                                                              \
    t8 = a ^ t1;                                                                                                              \
    t9 = t3 & t5;                                                                                                             \
    e = t8 ^ t9;                                                                                                              \
    t11 = f & e;                                                                                                              \
    h = t3 ^ t11;                                                                                                             \
}

/** @brief TANGRAM解密算法的P置换层（inverse ShiftRow）使用通用指令进行比特切片实现的指令序列。
 *
 *  @param [in,out] x0 inverse ShiftRow第 0 行的输入，并在原地执行循环右       0 位，得到第 0 行的输出
 *  @param [in,out] x1 inverse ShiftRow第 1 行的输入，并在原地执行循环右 ROL32_1 位，得到第 1 行的输出
 *  @param [in,out] x2 inverse ShiftRow第 2 行的输入，并在原地执行循环右 ROL32_2 位，得到第 2 行的输出
 *  @param [in,out] x3 inverse ShiftRow第 3 行的输入，并在原地执行循环右 ROL32_3 位，得到第 3 行的输出
 */
#define invert_permutation_1Block(x0, x1, x2, x3)                                                                             \
	{                                                                                                                         \
	x1 = ror32(x1, ROL32_1);                                                                                                  \
	x2 = ror32(x2, ROL32_2);                                                                                                  \
	x3 = ror32(x3, ROL32_3);                                                                                                  \
};

/** @brief TANGRAM解密算法的轮密钥加（inverse AddRoundKey）使用通用指令进行比特切片实现的指令序列。
 *  与TANGRAM加密算法的轮密钥加相同。
 *  @param [in,out] x0 TANGRAM状态矩阵的第 0 行，并在原地执行密钥加，得到第 0 行的输出
 *  @param [in,out] x1 TANGRAM状态矩阵的第 1 行，并在原地执行密钥加，得到第 1 行的输出
 *  @param [in,out] x2 TANGRAM状态矩阵的第 2 行，并在原地执行密钥加，得到第 2 行的输出
 *  @param [in,out] x3 TANGRAM状态矩阵的第 3 行，并在原地执行密钥加，得到第 3 行的输出
 *  @param [    in] kp 轮子密钥在内存中的起始地址
 */
#define invert_keyxor_1Block(x0, x1, x2, x3, kp) {                                                                                                                         \
	x3 ^= *(--kp);                                                                                                             \
	x2 ^= *(--kp);                                                                                                             \
	x1 ^= *(--kp);                                                                                                             \
	x0 ^= *(--kp);                                                                                                             \
}
/** @brief TANGRAM解密算法的轮函数使用通用指令进行比特切片实现的指令序列。
 *
 *  TANGRAM解密算法的轮函数是依次执行以下变换:
 *      - inverse AddRoundKey   对应于invert_keyxor_1Block()
 *      - inverse ShiftRow      对应于invert_permutation_1Block()
 *      - inverse SubColumn     对应于invert_sbox_1Block()
 *
 *  @param [ in] a  一轮密码状态的第 0 行输入
 *  @param [ in] b  一轮密码状态的第 1 行输入
 *  @param [ in] c  一轮密码状态的第 2 行输入
 *  @param [ in] d  一轮密码状态的第 3 行输入
 *  @param [out] e  一轮密码状态的第 0 行输出
 *  @param [out] f  一轮密码状态的第 1 行输出
 *  @param [out] g  一轮密码状态的第 2 行输出
 *  @param [out] h  一轮密码状态的第 3 行输出
 *  @param [ in] kp 轮子密钥在内存中的起始地址
 */
#define invert_round_1Block(a, b, c, d, e, f, g, h, kp)                                                                       \
{                                                                                                                             \
	invert_keyxor_1Block(a, b, c, d, kp);                                                                                     \
	invert_permutation_1Block(a, b, c, d);                                                                                    \
	invert_sbox_1Block(a, b, c, d, e, f, g, h);                                                                               \
}

/** @brief TANGRAM解密算法的最后一轮密钥加
 *
 *  TANGRAM解密算法的最后再次执行 AddRoundKey
 *
 *  @param [in,out] a  一轮密码状态的第 0 行输入，经过原地的与轮子密钥异或得到第 0 行输出
 *  @param [in,out] b  一轮密码状态的第 1 行输入，经过原地的与轮子密钥异或得到第 1 行输出
 *  @param [in,out] c  一轮密码状态的第 2 行输入，经过原地的与轮子密钥异或得到第 2 行输出
 *  @param [in,out] d  一轮密码状态的第 3 行输入，经过原地的与轮子密钥异或得到第 3 行输出
 *  @param [    in] kp 最后一轮子密钥在内存中的起始地址
 */
#define invert_last_round_1Block(a, b, c, d, kp)   invert_keyxor_1Block(a, b, c, d, kp);

/** @brief TANGRAM解密算法解密一个分组
 *
 *  TANGRAM的解密算法共包含 44 个相同的轮函数（除轮密钥不同），以及最后一轮密钥加。
 *  考虑到x64平台指令缓存较大，本实现全轮展开，避免变量的赋值。其中：

 *  - @a r0  一轮密码状态的第 0 行输入（偶数轮）或输出（奇数轮）
 *  - @a r1  一轮密码状态的第 1 行输入（偶数轮）或输出（奇数轮）
 *  - @a r2  一轮密码状态的第 2 行输入（偶数轮）或输出（奇数轮）
 *  - @a r3  一轮密码状态的第 3 行输入（偶数轮）或输出（奇数轮）
 *  - @a r4  一轮密码状态的第 0 行输入（奇数轮）或输出（偶数轮）
 *  - @a r5  一轮密码状态的第 1 行输入（奇数轮）或输出（偶数轮）
 *  - @a r6  一轮密码状态的第 2 行输入（奇数轮）或输出（偶数轮）
 *  - @a r7  一轮密码状态的第 3 行输入（奇数轮）或输出（偶数轮）
 *  - @a in  输入分组的起始地址
 *  - @a out 输出分组的起始地址
 *  - @a kp  扩展密钥在内存中的终止地址
 */
#define decrypt_1Block                                                                                \
{	   										    		                                              \
	input_1Block(r0, r1, r2, r3, in);  										                          \
	for(i=0;i<44;i++){                                                                            \
	    invert_round_1Block(r0, r1, r2, r3, r4, r5, r6, r7, kp);                                      \
	    r0=r4;r1=r5;r2=r6;r3=r7;                                                                      \
	}                                                                                                 \
	invert_last_round_1Block(r0, r1, r2, r3, kp);			                                          \
	output_1Block(r0, r1, r2, r3, out);						                                          \
}
#define decrypt_1Block_CBC                                                                            \
{	   										    		                                              \
	input_1Block(r0, r1, r2, r3, in);  										                  \
	for(i=0;i<44;i++){                                                                            \
	    invert_round_1Block(r0, r1, r2, r3, r4, r5, r6, r7, kp);                                      \
	    r0=r4;r1=r5;r2=r6;r3=r7;                                                                      \
	}                                                                                                 \
	invert_last_round_1Block(r0, r1, r2, r3, kp);			                                          \
	output_1Block_CBC(r0, r1, r2, r3, out, preout);					                                          \
}
/** @brief TANGRAM解密一个分组指定轮数
 *
 *  执行 @a rn 个相同的解密轮函数（除轮密钥不同），没有最后一轮密钥加。
 *  考虑到x64平台指令缓存较大，本实现 2 轮展开，避免变量的赋值。其中：
 *
 *  - @a r0  一轮密码状态的第 0 行输入（偶数轮）或输出（奇数轮）
 *  - @a r1  一轮密码状态的第 1 行输入（偶数轮）或输出（奇数轮）
 *  - @a r2  一轮密码状态的第 2 行输入（偶数轮）或输出（奇数轮）
 *  - @a r3  一轮密码状态的第 3 行输入（偶数轮）或输出（奇数轮）
 *  - @a r4  一轮密码状态的第 0 行输入（奇数轮）或输出（偶数轮）
 *  - @a r5  一轮密码状态的第 1 行输入（奇数轮）或输出（偶数轮）
 *  - @a r6  一轮密码状态的第 2 行输入（奇数轮）或输出（偶数轮）
 *  - @a r7  一轮密码状态的第 3 行输入（奇数轮）或输出（偶数轮）
 *  - @a in  输入分组的起始地址
 *  - @a out 输出分组的起始地址
 *  - @a kp  扩展密钥在内存中的起始地址
 */
#define decrypt_1Block_Round(rn)											                                              \
{																														      \
	input_1Block(r0, r1, r2, r3, in); 																					      \
	for(i=0;i<rn;i++){                                                                            \
	    invert_round_1Block(r0, r1, r2, r3, r4, r5, r6, r7, kp);                                      \
	    r0=r4;r1=r5;r2=r6;r3=r7;                                                                      \
	}                                                                                                 \
	invert_last_round_1Block(r0, r1, r2, r3, kp);			                                          \
	output_1Block(r0, r1, r2, r3, out);						                                          \
}





int Crypt_Enc_Block(
	unsigned char *input,
	int in_len,
	unsigned char *output,
	int *out_len,
	unsigned char *key,
	int keylen)
{
	ctx_t ctx;
	

	u32 r0, r1, r2, r3, r4, r5, r6, r7;
	u32 t0, t1, t2, t3, t4, t5, t6, t7, t8, t9, t10, t11;
	u32 *kp;
	u8 *in=input;u8 *out=output;
	int i;
	if ((in_len&(BLOCK_BYTE_NUMBER-1)) != 0)
	{
		printf("消息长度应当是 %d 的倍数（以字节计）;\n", BLOCK_BYTE_NUMBER);
		return FAILURE;
	}

	
	Key_Schedule(key, keylen, ENC, ctx.key);
	for (; in_len != 0; in_len -= BLOCK_BYTE_NUMBER)
	{
		kp = (u32 *)(ctx.key);
		encrypt_1Block;
		in  = in  + BLOCK_BYTE_NUMBER;
		out = out + BLOCK_BYTE_NUMBER;
	}
	*out_len = in_len;
	return SUCCESS;
}

int Crypt_Dec_Block(
	unsigned char *input,
	int in_len,
	unsigned char *output,
	int *out_len,
	unsigned char *key,
	int keylen)
{
	ctx_t ctx;
	

	u32 r0, r1, r2, r3, r4, r5, r6, r7;
	u32 t0, t1, t2, t3, t4, t5, t6, t7, t8, t9, t10, t11;
	u8 *in=input;
	u8 *out=output;
	u32 *kp;
	int i;
	if ((in_len&(BLOCK_BYTE_NUMBER-1)) != 0)
	{
		printf("消息长度应当是 %d 的倍数（以字节计）;\n", BLOCK_BYTE_NUMBER);
		return FAILURE;
	}

	Key_Schedule(key, keylen, DEC, ctx.key);
	//消息长度每次减去32个字节（256bit）
	for (; in_len != 0; in_len -= BLOCK_BYTE_NUMBER) {
		//对这一个分组长度的消息进行解密
		//确定明文地址
		//密钥编排算法在函数Crypt_Dec_Block中进行
		kp = ((u32 *)(ctx.key)) + (ROUND_NUMBER + 1)* BLOCK_WORD_NUMBER;
		decrypt_1Block;
		in  = in  + BLOCK_BYTE_NUMBER;
		out = out + BLOCK_BYTE_NUMBER;
	}
	*out_len = in_len;
	return SUCCESS;
}

int Crypt_Enc_Block_Round(
	unsigned char *input,
	int in_len,
	unsigned char *output,
	int *out_len,
	unsigned char *key,
	int keylen,
	int cryptround)
{
	ctx_t ctx;
	

	u32 r0, r1, r2, r3, r4, r5, r6, r7;
	u32 t0, t1, t2, t3, t4, t5, t6, t7, t8, t9, t10, t11;
	u32 *kp;
	u8 *in=input;u8 *out=output;
	int i;

	if ((in_len&(BLOCK_BYTE_NUMBER-1)) != 0)
	{
		printf("消息长度应当是 %d 的倍数（以字节计）;\n", BLOCK_BYTE_NUMBER);
		return FAILURE;
	}

	if (cryptround > ROUND_NUMBER)
	{
		printf("轮数应当小于总轮数 %d;\n", ROUND_NUMBER);
		return FAILURE;
	}
	
	Key_Schedule(key, keylen, ENC, ctx.key);
	for (; in_len != 0; in_len -= BLOCK_BYTE_NUMBER)
	{
		kp = (u32 *)(ctx.key);
		encrypt_1Block_Round(cryptround);
		in  = in  + BLOCK_BYTE_NUMBER;
		out = out + BLOCK_BYTE_NUMBER;
	}

	*out_len = in_len;
	return SUCCESS;
}

int Crypt_Dec_Block_Round(
	unsigned char *input,
	int in_len,
	unsigned char *output,
	int *out_len,
	unsigned char *key,
	int keylen,
	int cryptround)
{
	ctx_t ctx;
	
	u32 r0, r1, r2, r3, r4, r5, r6, r7;
	u32 t0, t1, t2, t3, t4, t5, t6, t7, t8, t9, t10, t11;
	int i;
	u8 *in=input;u8 *out=output;u32 *kp;

	if ((in_len&(BLOCK_BYTE_NUMBER-1)) != 0)
	{
		printf("消息长度应当是 %d 的倍数（以字节计）;\n", BLOCK_BYTE_NUMBER);
		return FAILURE;
	}

	if (cryptround > ROUND_NUMBER)
	{
		printf("轮数应当小于总轮数 %d;\n", ROUND_NUMBER);
		return FAILURE;
	}

	Key_Schedule(key, keylen, DEC, ctx.key);
	//消息长度每次减去32个字节（256bit）
	for (; in_len != 0; in_len -= BLOCK_BYTE_NUMBER) {
		//对这一个分组长度的消息进行解密
		//确定明文地址
		//密钥编排算法在函数Crypt_Dec_Block中进行
		kp = ((u32 *)(ctx.key)) + (ROUND_NUMBER + 1)* BLOCK_WORD_NUMBER;
		decrypt_1Block_Round(cryptround);
		in  = in  + BLOCK_BYTE_NUMBER;
		out = out + BLOCK_BYTE_NUMBER;
	}
	*out_len = in_len;
	return SUCCESS;
}
//消息长度一共有in_len字节
int Crypt_Enc_Block_CBC(
	unsigned char *input,
	int in_len,
	unsigned char *output,
	int *out_len,
	unsigned char *key,
	int keylen)
{
	u8 IV[16]={0};ctx_t ctx;
	
	u32 r0, r1, r2, r3, r4, r5, r6, r7;
	u32 t0, t1, t2, t3, t4, t5, t6, t7, t8, t9, t10, t11;
	u32 *kp;
	int i;
	u8 *in=input;u8 *preout=IV;u8 *out=output;

	if ((in_len&(BLOCK_BYTE_NUMBER-1)) != 0)
	{
		printf("消息长度应当是 %d 的倍数（以字节计）;\n", BLOCK_BYTE_NUMBER);
		return FAILURE;
	}
	Key_Schedule(key, keylen, ENC, ctx.key);
	//消息长度每次减去16个字节（128bit）
	for (; in_len != 0; in_len -= BLOCK_BYTE_NUMBER) {
		//对这一个分组长度的消息进行加密
		kp = (u32 *)(ctx.key);
		encrypt_1Block_CBC;
		in  = in  + BLOCK_BYTE_NUMBER;preout=out;
		out = out + BLOCK_BYTE_NUMBER;
	}
	*out_len = in_len;
	return SUCCESS;
}
//消息长度一共有in_len字节
int Crypt_Dec_Block_CBC(
	unsigned char *input,
	int in_len,
	unsigned char *output,
	int *out_len,
	unsigned char *key,
	int keylen)
{
	u8 IV[16]={0};ctx_t ctx;
	u32 r0, r1, r2, r3, r4, r5, r6, r7;
	u32 t0, t1, t2, t3, t4, t5, t6, t7, t8, t9, t10, t11;
	u32 *kp ;
	int i;
	u8 *in=input;u8 *preout=IV;u8 *out=output;
	if ((in_len&(BLOCK_BYTE_NUMBER-1)) != 0)
	{
		printf("消息长度应当是 %d 的倍数（以字节计）;\n", BLOCK_BYTE_NUMBER);
		return FAILURE;
	}
	
	Key_Schedule(key, keylen, DEC, ctx.key);
	//消息长度每次减去32个字节（256bit）
	for (; in_len != 0; in_len -= BLOCK_BYTE_NUMBER) {
		//对这一个分组长度的消息进行解密
		//确定明文地址
		//密钥编排算法在函数Crypt_Dec_Block中进行
		kp = ((u32 *)(ctx.key)) + (ROUND_NUMBER + 1)* BLOCK_WORD_NUMBER;
		decrypt_1Block_CBC;
		preout=in;
		in  = in  + BLOCK_BYTE_NUMBER;
		out = out + BLOCK_BYTE_NUMBER;
	}
	*out_len = in_len;
	return SUCCESS;
}