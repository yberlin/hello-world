﻿/** @file types.h
  * @brief 本文件包含数据类型的宏定义、使用的指令集的定义等。
  */
#ifndef TYPES_H__
#define TYPES_H__

/** @cond **/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <immintrin.h>
#include <nmmintrin.h>
#include <xmmintrin.h>
#include <emmintrin.h>
#include <pmmintrin.h>
#include <tmmintrin.h>
#include <smmintrin.h>
#include <wmmintrin.h>
#include <limits.h>
#include <math.h>
/** @endcond **/

#ifdef __GNUC__
#include <sched.h>
#include <unistd.h>
#endif

typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned int u32;
typedef unsigned long long u64;

/**
  * @def RegisterLengthInBits
  *                                 寄存器的长度（按比特计算）
  * @def RegisterLengthInBytes
  *                                 寄存器的长度（按字节计算）
  * @def RegisterLengthInWords
  *                                 寄存器的长度（按字  计算）
  * @def ParallelN
  *                                 并行处理的分组的格式
  */
#define RegisterLengthInBits  (1<<RegisterLengthInLog2)
#define RegisterLengthInBytes (1<<(RegisterLengthInLog2-3))
#define RegisterLengthInWords (1<<(RegisterLengthInLog2-4))

#define data_t u8


#endif //TYPES_H__
