﻿/** @file key.cpp
  * @brief 本文件包含TANGRAM密码算法的密钥编排相关的函数定义。
  */
#include "tangram256256.h"



/** @brief TANGRAM-256 经过S盒的列的个数*/
#define SBOXN_256 64           

/** @brief TANGRAM-256 广义Feistel结构中，右边梯子上循环移位参数*/
#define a_256  7 
/** @brief TANGRAM-256 广义Feistel结构中，左边梯子上循环移位参数*/
#define b_256  17               

/** @brief 轮常量数组，这里我们事先用函数 rc() 生成这个数组，通过查表使用轮常量*/
u64 RC[ROUND_NUMBER] = 
{
	0x1,
    0x2,
    0x4,
    0x8,
    0x10,
    0x20,
    0x41,
    0x3,
    0x6,
    0xc,
    0x18,
    0x30,
    0x61,
    0x42,
    0x5,
    0xa,
    0x14,
    0x28,
    0x51,
    0x23,
    0x47,
    0xf,
    0x1e,
    0x3c,
    0x79,
    0x72,
    0x64,
    0x48,
    0x11,
    0x22,
    0x45,
    0xb,
    0x16,
    0x2c,
    0x59,
    0x33,
    0x67,
    0x4e,
    0x1d,
    0x3a,
    0x75,
    0x6a,
    0x54,
    0x29,
    0x53,
    0x27,
    0x4f,
    0x1f,
    0x3e,
    0x7d,
    0x7a,
    0x74,
    0x68,
    0x50,
    0x21,
    0x43,
    0x7,
    0xe,
    0x1c,
    0x38,
    0x71,
    0x62,
    0x44,
    0x9,
    0x12,
    0x24,
    0x49,
    0x13,
    0x26,
    0x4d,
    0x1b,
    0x36,
    0x6d,
    0x5a,
    0x35,
    0x6b,
    0x56,
    0x2d,
    0x5b,
    0x37,
    0x6f,
    0x5e,
};

/** @brief 生成轮常量的 LFSR 的初始状态*/
#define RC0 0x1

/** @brief 生成轮常量的 LFSR */
//7bit线性反馈移位寄存器
#define rc_round(n)                                                    \
{                                                                      \
	RC[n] = ((RC[n-1]<<1) | (((RC[n-1]>>5)^(RC[n-1]>>6)) & 0x1))&0x7f; \
	}

/** @brief 生成轮常量的函数 */
void rc()
{

#if 1 //生成轮常量的查表，但不打印。
	RC[0] = RC0;
	rc_round(1);	rc_round(2);	rc_round(3);	rc_round(4);	rc_round(5);
	rc_round(6);	rc_round(7);	rc_round(8);	rc_round(9);	rc_round(10);
	rc_round(11);	rc_round(12);	rc_round(13);	rc_round(14);	rc_round(15);
	rc_round(16);	rc_round(17);	rc_round(18);	rc_round(19);	rc_round(20);
	rc_round(21);	rc_round(22);	rc_round(23);	rc_round(24);   rc_round(25);
	rc_round(26);	rc_round(27);	rc_round(28);	rc_round(29);	rc_round(30);
	rc_round(31);	rc_round(32);	rc_round(33);	rc_round(34);   rc_round(35);
	rc_round(36);	rc_round(37);	rc_round(38);	rc_round(39);	rc_round(40);
	rc_round(41);	rc_round(42);	rc_round(43);   rc_round(44);	rc_round(45);
	rc_round(46);	rc_round(47);	rc_round(48);	rc_round(49);	rc_round(50);
	rc_round(51);	rc_round(52);	rc_round(53);	rc_round(54);	rc_round(55);
	rc_round(56);	rc_round(57);	rc_round(58);	rc_round(59);	rc_round(60);
	rc_round(61);	rc_round(62);	rc_round(63);	rc_round(64);   rc_round(65);
	rc_round(66);	rc_round(67);	rc_round(68);	rc_round(69);	rc_round(70);
	rc_round(71);	rc_round(72);	rc_round(73);	rc_round(74);   rc_round(75);
	rc_round(76);	rc_round(77);	rc_round(78);	rc_round(79);	rc_round(80);
	rc_round(81);
#endif
}

/** @brief 轮常量加 */
#define key_rc(w0, n)                                                  \
{					                                                   \
	w0 ^= RC[n];	                                                   \
}

/** @brief 输出轮密钥 */
#define key_out(w0, w1, w2, w3, n)                                     \
{                                                                      \
	subKey[n*BLOCK_WORD_NUMBER + 0] = (u64)(w0);                       \
	subKey[n*BLOCK_WORD_NUMBER + 1] = (u64)(w1);                       \
	subKey[n*BLOCK_WORD_NUMBER + 2] = (u64)(w2);                       \
	subKey[n*BLOCK_WORD_NUMBER + 3] = (u64)(w3);                       \
}

/** @brief 将变量 @a x 的第 @a n 个64-比特字取出 */
#define word64_in(x, n) (((u64*)(x))[n])

/** @brief 将256比特主密钥装载到状态寄存器 */
#define key256_in(w0, w1, w2, w3, x2)                                  \
{                                                                      \
	w0 = word64_in(x2, 0);                                             \
	w1 = word64_in(x2, 1);                                             \
	w2 = word64_in(x2, 2);                                             \
	w3 = word64_in(x2, 3);                                             \
}

/** @brief TANGRAM-256 的密钥状态的4个分支的8列经过S盒变换 */
#define key256_sbox(w0, w1, w2, w3)                                    \
{                                                                      \
	t1 = w0 ^ w2;                                                      \
    t2 = w0 & w1;                                                      \
    t3 = w3 ^ t2;                                                      \
    g = w2 ^ t3;                                                       \
    t5 = w1 ^ w2;                                                      \
    t6 = t1 & t3;                                                      \
    e = t5 ^ t6;                                                       \
    t8 = w1 | w3;                                                      \
    t9 = t1 ^ t8;                                                      \
    h = ~t9;                                                           \
    t11 = t5 & t9;                                                     \
    f = t3 ^ t11;                                                      \
	w0 = e;                                                            \
	w1 = f;                                                            \
	w2 = g;                                                            \
	w3 = h;                                                            \
}

/** @brief TANGRAM-256 的密钥编排的一轮4-分支Feistel变换 */
//这里没有进行feistel移位
#define key256_rol(w0, w1, w2, w3)                                     \
{                                                                      \
	t0 = rol64(w0, a_256);				                               \
	t1 = rol64(w2, b_256);				                               \
	w1 ^= t0;						                                   \
	w3 ^= t1; 					                                       \
}

/** @brief TANGRAM-256 的密钥编排的一轮 */
#define key256_round(w0, w1, w2, w3, n)                                \
{                                                                      \
	key_out(w0, w1, w2, w3, n);                                        \
	key256_sbox(w0, w1, w2, w3);                                       \
	key256_rol(w0, w1, w2, w3);                                        \
	key_rc(w1, n);                                                     \
}

/** @brief TANGRAM-256 的最后一轮子密钥 */
#define key256_lround(w0, w1, w2, w3, n)                               \
{                                                                      \
	key_out(w0, w1, w2, w3, n);                                        \
}

/** @brief TANGRAM-256 的密钥编排 */

void key256(u8 *userKey, u64 *subKey)
{
	//volatile double sum = 1.0; for(int i = 0; i < 1000000; i++) { sum =1; };
	u64 k0, k1, k2, k3;
	u64 t0, t1, t2, t3, t4, t5, t6, t7, t8, t9, t10, t11;
	u64 e, f, g, h;
	int i;
	u64 tmp;

	key256_in(k0, k1, k2, k3, userKey);
	for(i=0;i<80;i++){
		key256_round(k0, k1, k2, k3, i);
	    tmp=k0;
		k0=k1;k1=k2;k2=k3;k3=tmp;
	}
	key256_round(k0, k1, k2, k3, 80);
	key256_round(k1, k2, k3, k0, 81);
	key256_lround(k2, k3, k0, k1, 82);
}

void Key_Schedule(
	unsigned char *Seedkey, 
	int KeyLen, 
	unsigned char Direction, 
	unsigned char *Subkey)
{
	switch(KeyLen)
	{
	case 32: key256(Seedkey, (u64 *)Subkey); break;
	default: printf("密钥长度错误，应当是32（以字节计）。\n"); exit(1);
	}
}
