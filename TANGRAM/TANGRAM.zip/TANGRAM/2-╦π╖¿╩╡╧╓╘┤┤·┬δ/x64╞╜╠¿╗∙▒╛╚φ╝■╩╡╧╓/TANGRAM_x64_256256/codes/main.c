﻿/** @file main.cpp
 * @brief 本文件是主函数的定义，调用测试正确性的函数和测试速度的函数进行测试。
 */

#include"intrin.h"
#include"rot.h"
#include"tangram256256.h"
#include"types.h"

#define RAND(a,b) (((a = 36969 * (a & 65535) + (a >> 16)) << 16) + \
	(b = 18000 * (b & 65535) + (b >> 16))  )

__inline unsigned long long read_tsc(void)
{
	return __rdtsc();
}
void block_rndfill(unsigned char *buf, const int len)
{
	static unsigned long a[2], mt = 1, count = 4;
	static unsigned char r[4];
	int                  i;

	//  我们使用处理器CPUID读取时间戳来对其初始化。
	if(mt) { mt = 0; *(unsigned long long*)a = read_tsc(); }

	for(i = 0; i < len; ++i)
	{
		if(count == 4)
		{
			*(unsigned long*)r = RAND(a[0], a[1]);
			count = 0;
		}

		buf[i] = r[count++];
	}
}
int main()
{
    int out_len;
	unsigned char    key[3][32];
	unsigned char    plain[30][32];
	unsigned char    cipher[30][32];

	block_rndfill(key[0], 32);
	block_rndfill(plain[0], 3*32);

	Crypt_Enc_Block(plain[0], 3*32, cipher[0], &out_len, key[0], 32);

	getchar();
	return 0;
}
