﻿
#ifndef ROT_H__
#define ROT_H__
#include "types.h"

  /**
  * @def ror16(x, n)
  *                  16-比特字@a x 上右循环移@a n 位
  * @def rol16(x, n)
  *                  16-比特字@a x 上左循环移@a n 位
  * @def ror32(x, n)
  *                  32-比特字@a x 上右循环移@a n 位
  * @def rol32(x, n)
  *                  32-比特字@a x 上左循环移@a n 位
  * @def ror64(x, n)
  *                  64-比特字@a x 上右循环移@a n 位
  * @def rol64(x, n)
  *                  64-比特字@a x 上左循环移@a n 位
  */
#define ror16(x, n)   (((x) >> ((int)((n) & 0xf))) | ((x) << ((int)((16 - ((n) & 0xf))))) & 0xffff) 
#define rol16(x, n)   (((x) << ((int)((n) & 0xf))) | ((x) >> ((int)((16 - ((n) & 0xf))))) & 0xffff) 
#define ror32(x, n)   (((x) >> ((int)((n) & 0x1f))) | ((x) << ((int)((32 - ((n) & 0x1f))))) & 0xffffffff) 
#define rol32(x, n)   (((x) << ((int)((n) & 0x1f))) | ((x) >> ((int)((32 - ((n) & 0x1f))))) & 0xffffffff) 
#define ror64(x, n)   (((x) >> ((unsigned long long)((n) & 0x3f))) | ((x) << ((unsigned long long)((64 - ((n) & 0x3f))))) & 0xffffffffffffffffULL) 
#define rol64(x, n)   (((x) << ((unsigned long long)((n) & 0x3f))) | ((x) >> ((unsigned long long)((64 - ((n) & 0x3f))))) & 0xffffffffffffffffULL) 


#endif //ROT_H__
