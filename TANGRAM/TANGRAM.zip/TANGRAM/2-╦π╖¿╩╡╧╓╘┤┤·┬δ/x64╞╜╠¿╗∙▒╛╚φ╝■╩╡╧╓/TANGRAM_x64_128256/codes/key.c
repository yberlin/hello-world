﻿/** @file key.cpp
  * @brief 本文件包含TANGRAM密码算法的密钥编排相关的函数定义。
  */
#include "tangram128256.h"

/** @brief TANGRAM 128/256 经过S盒的列的个数*/
#define SBOXN_128 32           

/** @brief TANGRAM 128/256 广义Feistel结构中，右边梯子上循环移位参数*/
#define a_128  7 
/** @brief TANGRAM 128/256 广义Feistel结构中，左边梯子上循环移位参数*/
#define b_128  17             

/** @brief TANGRAM 128/256 经过S盒的列的掩码 */
#define SM_128 (0xffffffff)
/** @brief TANGRAM 128/256 不经过S盒的列的掩码 */
#define WM_128 (0x00000000)   

/** @brief 轮常量数组，这里我们事先用函数 rc() 生成这个数组，通过查表使用轮常量*/
u32 RC[ROUND_NUMBER] = 
{
	0x1,
    0x2,
    0x4,
    0x8,
    0x10,
    0x21,
    0x3,
    0x6,
    0xc,
    0x18,
    0x31,
    0x22,
    0x5,
    0xa,
    0x14,
    0x29,
    0x13,
    0x27,
    0xf,
    0x1e,
    0x3d,
    0x3a,
    0x34,
    0x28,
    0x11,
    0x23,
    0x7,
    0xe,
    0x1c,
    0x39,
    0x32,
    0x24,
    0x9,
    0x12,
    0x25,
    0xb,
    0x16,
    0x2d,
    0x1b,
    0x37,
    0x2e,
    0x1d,
    0x3b,
    0x36,
	0x2c,
    0x19,
    0x33,
    0x26,
    0xd,
};

/** @brief 生成轮常量的 LFSR 的初始状态*/
#define RC0 0x1

/** @brief 生成轮常量的 LFSR */
//6位线性反馈移位寄存器
#define rc_round(n)                                                    \
{                                                                      \
	RC[n] = ((RC[n-1]<<1) | (((RC[n-1]>>4)^(RC[n-1]>>5)) & 0x1))&0x3f; \
	}

/** @brief 生成轮常量的函数 */
void rc()
{
#if 1 //生成轮常量的查表，但不打印。
	RC[0] = RC0;
	rc_round(1);	rc_round(2);	rc_round(3);	rc_round(4);	rc_round(5);
	rc_round(6);	rc_round(7);	rc_round(8);	rc_round(9);	rc_round(10);
	rc_round(11);	rc_round(12);	rc_round(13);	rc_round(14);	rc_round(15);
	rc_round(16);	rc_round(17);	rc_round(18);	rc_round(19);	rc_round(20);
	rc_round(21);	rc_round(22);	rc_round(23);	rc_round(24);   rc_round(25);
	rc_round(26);	rc_round(27);	rc_round(28);	rc_round(29);	rc_round(30);
	rc_round(31);	rc_round(32);	rc_round(33);	rc_round(34);   rc_round(35);
	rc_round(36);	rc_round(37);	rc_round(38);	rc_round(39);	rc_round(40);
	rc_round(41);	rc_round(42);	rc_round(43);   rc_round(44);   rc_round(45);
	rc_round(46);	rc_round(47);	rc_round(48);	
#endif
}

/** @brief 轮常量加 */

#define key_rc(w0, n)                                                  \
{					                                                   \
	w0 ^= RC[n];	                                                   \
}

/** @brief 输出轮密钥 */
#define key_out(w0, w1, w2, w3, n)                                     \
{                                                                      \
	subKey[n*BLOCK_WORD_NUMBER + 0] = (u32)(w0);                       \
	subKey[n*BLOCK_WORD_NUMBER + 1] = (u32)(w1);                       \
	subKey[n*BLOCK_WORD_NUMBER + 2] = (u32)(w2);                       \
	subKey[n*BLOCK_WORD_NUMBER + 3] = (u32)(w3);                       \
}

/** @brief 将变量 @a x 的第 @a n 个32-比特字取出 */
#define word32_in(x, n) (((u32*)(x))[n])

/** @brief 将128比特主密钥装载到状态寄存器 */
#define key128_in(w0, w1, w2, w3, x2)                                  \
{                                                                      \
	w0 = word32_in(x2, 0);                                             \
	w1 = word32_in(x2, 1);                                             \
	w2 = word32_in(x2, 2);                                             \
	w3 = word32_in(x2, 3);                                             \
}

/** @brief TANGRAM 128/256 的密钥状态的4个分支的8列经过S盒变换 */
#define key128_sbox(w0, w1, w2, w3)                                    \
{                                                                      \
	t1 = w0 ^ w2;                                                      \
    t2 = w0 & w1;                                                      \
    t3 = w3 ^ t2;                                                      \
    g = w2 ^ t3;                                                       \
    t5 = w1 ^ w2;                                                      \
    t6 = t1 & t3;                                                      \
    e = t5 ^ t6;                                                       \
    t8 = w1 | w3;                                                      \
    t9 = t1 ^ t8;                                                      \
    h = ~t9;                                                           \
    t11 = t5 & t9;                                                     \
    f = t3 ^ t11;                                                      \
	w0 = e;                                                            \
	w1 = f;                                                            \
	w2 = g;                                                            \
	w3 = h;                                                            \
}

/** @brief TANGRAM 128/256 的密钥编排的一轮4-分支Feistel变换 */
//这里没有进行feistel移位
#define key128_rol(w0, w1, w2, w3)                                     \
{                                                                      \
	t0 = rol32(w0, a_128);				                               \
	t1 = rol32(w2, b_128);				                               \
	w1 ^= t0;						                                   \
	w3 ^= t1; 					                                       \
}

/** @brief TANGRAM 128/256 的密钥编排的一轮 */
//生成r+2轮密钥，w0-w3表示r+1轮密钥，w4-w7表示r轮密钥
#define key128_round(w0, w1, w2, w3, w4, w5, w6, w7, n)                \
{                                                                      \
	u32 k8, k9, k10, k11;                                              \
	k8=w0;                                                             \
	k9=w1;                                                             \
	k10=w2;                                                            \
	k11=w3;                                                            \
	key128_sbox(k8, k9, k10, k11);                                     \
	key128_rol(k8, k9, k10, k11);                                      \
	key_rc(k9, n);                                                     \
	w4 ^=k9;                                                           \
    w5 ^=k10;                                                          \
	w6 ^=k11;                                                          \
	w7 ^=k8;                                                           \
	key_out(w4, w5, w6, w7, (n+2));                                    \
}

/** @brief TANGRAM 128/256 的最后一轮子密钥 */
#define key128_lround(w0, w1, w2, w3, n)                               \
{                                                                      \
	key_out(w0, w1, w2, w3, n);                                        \
}

/** @brief TANGRAM 128/256 的密钥编排 */
void key128(u8 *userKey, u32 *subKey)
{
	u32 k0, k1, k2, k3, k4, k5, k6, k7;
	u32 t0, t1, t2, t3, t4, t5, t6, t7, t8, t9, t10, t11;
	u32 e, f, g, h;
	u32 tmp1,tmp2,tmp3,tmp4;
	int i;
	//生成第一轮初始密钥
	key128_in(k4, k5, k6, k7, userKey);
	subKey[4] = k4; subKey[5] = k5; subKey[6] = k6; subKey[7] = k7;
	
	//userkey的地址后移128位
	userKey  = userKey  + BLOCK_BYTE_NUMBER;
	//生成第二轮初始密钥
	key128_in(k0, k1, k2, k3, userKey);
	subKey[0] = k0; subKey[1] = k1; subKey[2] = k2; subKey[3] = k3; 
	//4567第二轮密钥，0123第一轮密钥
	for(i=0;i<48;i++){
		key128_round(k4, k5, k6, k7, k0, k1, k2, k3, i);
		tmp1=k4;tmp2=k5;tmp3=k6;tmp4=k7;
		k4=k0;k5=k1;k6=k2;k7=k3;
		k0=tmp1;k1=tmp2;k2=tmp3;k3=tmp4;
	}
	key128_round(k4, k5, k6, k7, k0, k1, k2, k3, 48);
}


void Key_Schedule(
	unsigned char *Seedkey, 
	int KeyLen, 
	unsigned char Direction, 
	unsigned char *Subkey)
{
	switch(KeyLen)
	{
	    case 32: key128(Seedkey, (u32 *)Subkey); break;
	    default: printf("密钥长度错误，应当是32（以字节计）。\n"); exit(1);
	}
}
