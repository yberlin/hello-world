﻿#include"128128avx.h"
u32 RC[44] =
{
	0x1,0x2,0x4,0x8,0x10,0x21,0x3,0x6,0xc,0x18,0x31,0x22,0x5,0xa,0x14,0x29,0x13,0x27,
	0xf,0x1e,0x3d,0x3a,0x34,0x28,0x11,0x23,0x7,0xe,0x1c,0x39,0x32,0x24,0x9,0x12,0x25,
	0xb,0x16,0x2d,0x1b,0x37,0x2e,0x1d,0x3b,0x36,
};
void printBLOCKTXT(FILE *fp, const char* str, u8 *s, int len) {
#ifdef PRINTBLOCKTXT
	int i, j;
	fprintf(fp, "%-9s   :\n", str);
	for (i = 0; i < len; i++) {
		fprintf(fp, "%02x,", s[i]);
		if (i % 32 == 31)
			fprintf(fp, "\n");
	}
	fprintf(fp, "\n");
#endif
}

void printSubKeyTXT(FILE *fp, u8 *Subkey) {
#ifdef PRINTSubKeyTXT
	int i, j;
	fprintf(fp, "SubKey:\n");
	for (j = 0; j < 45; j++) {
		fprintf(fp, "%-3d ：", j);
		for (i = 0; i < 16; i++) {
			fprintf(fp, "%02x", Subkey[j * 16 + i]);
		}
		fprintf(fp, "\n");
	}
#endif
}
void printBLOCK(const char* str, u8 *s, int len) {
#ifdef PRINTBLOCK
	int i, j;
	printf("%-9s   :\n", str);
	for (i = 0; i < len; i++) {
		printf("%02x,", s[i]);
		if (i % 32 == 31)
			printf("\n");
	}
	printf("\n");
#endif
}
void printSubKey(u8 *Subkey) {
#ifdef PRINTSubKey
	int i, j;
	for (j = 0; j < 45; j++) {
		printf("%d ：\n", j);
		for (i = 0; i < 16; i++) {
			printf("%02x", Subkey[j * 16 + i]);
		}
		printf("\n");
	}
#endif
}
//void tangram_128_KeySchedule(unsigned char *Seedkey, unsigned char *Subkey)

int Key_Schedule(unsigned char * seedkey,int keylen,int direction,unsigned char * subkey){
	
	int i;
	u32 k0, k1, k2, k3;
	u32 t0, t1, t2, t3, t4, t5, t6, t7, t8, t9, t10, t11;
	u32 e, f, g, h;
	u32 tmp;
	
	if (keylen != KEYBYTE) {
		printf("ERROR  密钥长度不是  %d byte  ",KEYBYTE);
		return 0;
	}
	k0 = ((u32*)seedkey)[0];
	k1 = ((u32*)seedkey)[1];
	k2 = ((u32*)seedkey)[2];
	k3 = ((u32*)seedkey)[3];
	for (i = 0; i < ROUNDNUM; i++) {
		//Subkey
		*(u32*)subkey = k0;
		subkey += 4;
		*(u32*)subkey = k1;
		subkey += 4;
		*(u32*)subkey = k2;
		subkey += 4;
		*(u32*)subkey = k3;
		subkey += 4;
		//Sbox
		key128_sbox(k0, k1, k2, k3);
		key128_rol(k0, k1, k2, k3);
		k1 ^= RC[i];
		//feistel移位
		tmp = k0;
		k0 = k1; k1 = k2; k2 = k3; k3 = tmp;
	}
	//Subkey
	*(u32*)subkey = k0;
	subkey += 4;
	*(u32*)subkey = k1;
	subkey += 4;
	*(u32*)subkey = k2;
	subkey += 4;
	*(u32*)subkey = k3;
	subkey += 4;
}

void tangram_128_Encrypt(unsigned char *plain, unsigned char *cipher, unsigned char *Subkey)
{
	//printf("tangram_128_Encrypt\n");
	u256 w0, w1, w2, w3;
	u256 tmm0, tmm1, tmm2, tmm3, tmm4, tmm5, tmm6, tmm7, tmm8, tmm9, tmm10, tmm11;
	u256 e, f, g, h;
	int i = 0;
	u256 kmm0, kmm1, kmm2, kmm3;
	u256 all1 = _mm256_set1_epi32(0xffffffff);
	u256 ymm01, ymm13, ymm02, ymm23, ymm45, ymm57, ymm46, ymm67;
	ymm01 = _mm256_loadu_si256((__m256i *)(plain + (0 * 32)));
	ymm23 = _mm256_loadu_si256((__m256i *)(plain + (1 * 32)));
	ymm45 = _mm256_loadu_si256((__m256i *)(plain + (2 * 32)));
	ymm67 = _mm256_loadu_si256((__m256i *)(plain + (3 * 32)));

	tmm0 = _mm256_unpacklo_epi64(ymm01, ymm23);
	tmm1 = _mm256_unpackhi_epi64(ymm01, ymm23);
	tmm2 = _mm256_unpacklo_epi64(ymm45, ymm67);
	tmm3 = _mm256_unpackhi_epi64(ymm45, ymm67);


	ymm02 = _mm256_unpacklo_epi64(tmm0, tmm2);
	ymm13 = _mm256_unpackhi_epi64(tmm0, tmm2);

	ymm46 = _mm256_unpacklo_epi64(tmm1, tmm3);
	ymm57 = _mm256_unpackhi_epi64(tmm1, tmm3);

	tmm0 = _mm256_unpacklo_epi32(ymm02, ymm13);
	tmm1 = _mm256_unpackhi_epi32(ymm02, ymm13);
	tmm2 = _mm256_unpacklo_epi32(ymm46, ymm57);
	tmm3 = _mm256_unpackhi_epi32(ymm46, ymm57);
	w0 = _mm256_unpacklo_epi64(tmm0, tmm1);
	w1 = _mm256_unpackhi_epi64(tmm0, tmm1);
	w2 = _mm256_unpacklo_epi64(tmm2, tmm3);
	w3 = _mm256_unpackhi_epi64(tmm2, tmm3);

	for (i = 0; i < ROUNDNUM; i++) {
		ROUND128_Encrypt(i);
	}
	//AddRoundKey（ARK）
	kmm0 = _mm256_set1_epi32(((u32*)Subkey)[0 + i * 4]);
	kmm1 = _mm256_set1_epi32(((u32*)Subkey)[1 + i * 4]);
	kmm2 = _mm256_set1_epi32(((u32*)Subkey)[2 + i * 4]);
	kmm3 = _mm256_set1_epi32(((u32*)Subkey)[3 + i * 4]);

	w0 = _mm256_xor_si256(w0, kmm0);
	w1 = _mm256_xor_si256(w1, kmm1);
	w2 = _mm256_xor_si256(w2, kmm2);
	w3 = _mm256_xor_si256(w3, kmm3);

	ymm02 = _mm256_unpacklo_epi64(w0, w1);
	ymm13 = _mm256_unpackhi_epi64(w0, w1);
	ymm46 = _mm256_unpacklo_epi64(w2, w3);
	ymm57 = _mm256_unpackhi_epi64(w2, w3);
	w0 = _mm256_unpacklo_epi32(ymm02, ymm46);
	w1 = _mm256_unpackhi_epi32(ymm02, ymm46);
	w2 = _mm256_unpacklo_epi32(ymm13, ymm57);
	w3 = _mm256_unpackhi_epi32(ymm13, ymm57);
	ymm02 = _mm256_unpacklo_epi32(w0, w1);
	ymm13 = _mm256_unpackhi_epi32(w0, w1);
	ymm46 = _mm256_unpacklo_epi32(w2, w3);
	ymm57 = _mm256_unpackhi_epi32(w2, w3);

	_mm256_storeu_si256((__m256i *)(cipher + (0 * 32)), ymm02);
	_mm256_storeu_si256((__m256i *)(cipher + (1 * 32)), ymm13);
	_mm256_storeu_si256((__m256i *)(cipher + (2 * 32)), ymm46);
	_mm256_storeu_si256((__m256i *)(cipher + (3 * 32)), ymm57);
}

void tangram_128_Decrypt(unsigned char *cipher, unsigned char *plain, unsigned char *Subkey)
{
	//printf("tangram_128_Decrypt\n");
	u256 w0, w1, w2, w3;
	u256 tmm0, tmm1, tmm2, tmm3, tmm4, tmm5, tmm6, tmm7, tmm8, tmm9, tmm10, tmm11;
	u256 e, f, g, h;
	int i = 0;
	u256 kmm0, kmm1, kmm2, kmm3;
	u256 all1 = _mm256_set1_epi32(0xffffffff);
	u256 ymm01, ymm13, ymm02, ymm23, ymm45, ymm57, ymm46, ymm67;

	ymm01 = _mm256_loadu_si256((__m256i *)(cipher + (0 * 32)));		                                                              \
		ymm23 = _mm256_loadu_si256((__m256i *)(cipher + (1 * 32)));		                                                              \
		ymm45 = _mm256_loadu_si256((__m256i *)(cipher + (2 * 32)));		                                                              \
		ymm67 = _mm256_loadu_si256((__m256i *)(cipher + (3 * 32)));

	tmm0 = _mm256_unpacklo_epi64(ymm01, ymm23);
	tmm1 = _mm256_unpackhi_epi64(ymm01, ymm23);
	tmm2 = _mm256_unpacklo_epi64(ymm45, ymm67);
	tmm3 = _mm256_unpackhi_epi64(ymm45, ymm67);


	ymm02 = _mm256_unpacklo_epi64(tmm0, tmm2);
	ymm13 = _mm256_unpackhi_epi64(tmm0, tmm2);

	ymm46 = _mm256_unpacklo_epi64(tmm1, tmm3);
	ymm57 = _mm256_unpackhi_epi64(tmm1, tmm3);

	tmm0 = _mm256_unpacklo_epi32(ymm02, ymm13);
	tmm1 = _mm256_unpackhi_epi32(ymm02, ymm13);
	tmm2 = _mm256_unpacklo_epi32(ymm46, ymm57);
	tmm3 = _mm256_unpackhi_epi32(ymm46, ymm57);
	w0 = _mm256_unpacklo_epi64(tmm0, tmm1);
	w1 = _mm256_unpackhi_epi64(tmm0, tmm1);
	w2 = _mm256_unpacklo_epi64(tmm2, tmm3);
	w3 = _mm256_unpackhi_epi64(tmm2, tmm3);
	for (i = ROUNDNUM; i > 0; i--) {
		ROUND128_Decrypt(i);
	}
	//AddRoundKey（ARK）
	kmm0 = _mm256_set1_epi32(((u32*)Subkey)[0 + i * 4]);
	kmm1 = _mm256_set1_epi32(((u32*)Subkey)[1 + i * 4]);
	kmm2 = _mm256_set1_epi32(((u32*)Subkey)[2 + i * 4]);
	kmm3 = _mm256_set1_epi32(((u32*)Subkey)[3 + i * 4]);
	w0 = _mm256_xor_si256(w0, kmm0);
	w1 = _mm256_xor_si256(w1, kmm1);
	w2 = _mm256_xor_si256(w2, kmm2);
	w3 = _mm256_xor_si256(w3, kmm3);

	ymm02 = _mm256_unpacklo_epi64(w0, w1);
	ymm13 = _mm256_unpackhi_epi64(w0, w1);
	ymm46 = _mm256_unpacklo_epi64(w2, w3);
	ymm57 = _mm256_unpackhi_epi64(w2, w3);
	w0 = _mm256_unpacklo_epi32(ymm02, ymm46);
	w1 = _mm256_unpackhi_epi32(ymm02, ymm46);
	w2 = _mm256_unpacklo_epi32(ymm13, ymm57);
	w3 = _mm256_unpackhi_epi32(ymm13, ymm57);
	ymm02 = _mm256_unpacklo_epi32(w0, w1);
	ymm13 = _mm256_unpackhi_epi32(w0, w1);
	ymm46 = _mm256_unpacklo_epi32(w2, w3);
	ymm57 = _mm256_unpackhi_epi32(w2, w3);

	_mm256_storeu_si256((__m256i *)(plain + (0 * 32)), ymm02);
	_mm256_storeu_si256((__m256i *)(plain + (1 * 32)), ymm13);
	_mm256_storeu_si256((__m256i *)(plain + (2 * 32)), ymm46);
	_mm256_storeu_si256((__m256i *)(plain + (3 * 32)), ymm57);

}

void FinalParallelIn(int in_len, unsigned char *input, unsigned char* tempin) {
	int i, g = 0;
	u256 t1, t2, t3;
	__m128i t0;

	switch ((in_len % ParallelBYTE) / BLOCKBYTE) {
	case 2:
		t1 = _mm256_loadu_si256((__m256i*)(input));
		_mm256_storeu_si256((__m256i *)(tempin + g * ParallelBYTE), t1);
		break;

	case 4:
		t1 = _mm256_loadu_si256((__m256i*)(input));
		_mm256_storeu_si256((__m256i *)(tempin + g * ParallelBYTE), t1);

		t2 = _mm256_loadu_si256((__m256i*)(input + ParallelOFFSETBYTE));
		_mm256_storeu_si256((__m256i *)(tempin + g * ParallelBYTE + ParallelOFFSETBYTE), t2);

		break;
	case 6:
		t1 = _mm256_loadu_si256((__m256i*)(input));
		_mm256_storeu_si256((__m256i *)(tempin + g * ParallelBYTE), t1);

		t2 = _mm256_loadu_si256((__m256i*)(input + ParallelOFFSETBYTE));
		_mm256_storeu_si256((__m256i *)(tempin + g * ParallelBYTE + ParallelOFFSETBYTE), t2);

		t3 = _mm256_loadu_si256((__m256i*)(input + ParallelOFFSETBYTE * 2));
		_mm256_storeu_si256((__m256i *)(tempin + g * ParallelBYTE + ParallelOFFSETBYTE * 2), t3);
		break;


	case 1:
		t0 = _mm_loadu_si128((__m128i*)(input));
		_mm_storeu_si128((__m128i *)(tempin + g * ParallelBYTE), t0);
		break;
	case 3:
		t1 = _mm256_loadu_si256((__m256i*)(input));
		_mm256_storeu_si256((__m256i *)(tempin + g * ParallelBYTE), t1);
		t0 = _mm_loadu_si128((__m128i*)(input + ParallelOFFSETBYTE));
		_mm_storeu_si128((__m128i *)(tempin + g * ParallelBYTE + ParallelOFFSETBYTE), t0);
		break;

	case 5:
		t1 = _mm256_loadu_si256((__m256i*)(input));
		_mm256_storeu_si256((__m256i *)(tempin + g * ParallelBYTE), t1);

		t2 = _mm256_loadu_si256((__m256i*)(input + ParallelOFFSETBYTE));
		_mm256_storeu_si256((__m256i *)(tempin + g * ParallelBYTE + ParallelOFFSETBYTE), t2);
		t0 = _mm_loadu_si128((__m128i*)(input + ParallelOFFSETBYTE * 2));
		_mm_storeu_si128((__m128i *)(tempin + g * ParallelBYTE + ParallelOFFSETBYTE * 2), t0);

		break;
	case 7:
		t1 = _mm256_loadu_si256((__m256i*)(input));
		_mm256_storeu_si256((__m256i *)(tempin + g * ParallelBYTE), t1);

		t2 = _mm256_loadu_si256((__m256i*)(input + ParallelOFFSETBYTE));
		_mm256_storeu_si256((__m256i *)(tempin + g * ParallelBYTE + ParallelOFFSETBYTE), t2);

		t3 = _mm256_loadu_si256((__m256i*)(input + ParallelOFFSETBYTE * 2));
		_mm256_storeu_si256((__m256i *)(tempin + g * ParallelBYTE + ParallelOFFSETBYTE * 2), t3);
		t0 = _mm_loadu_si128((__m128i*)(input + ParallelOFFSETBYTE * 3));
		_mm_storeu_si128((__m128i *)(tempin + g * ParallelBYTE + ParallelOFFSETBYTE * 3), t0);
		break;
	}
}


void FinalParallelOut(int in_len, unsigned char *output, unsigned char* tempout) {
	int i, g = 0;
	u256 t1, t2, t3;
	__m128i t0;

	switch ((in_len % ParallelBYTE) / BLOCKBYTE) {
	case 2:
		t1 = _mm256_loadu_si256((__m256i*)(tempout));
		_mm256_storeu_si256((__m256i *)(output + g * ParallelBYTE), t1);
		break;

	case 4:
		t1 = _mm256_loadu_si256((__m256i*)(tempout));
		_mm256_storeu_si256((__m256i *)(output + g * ParallelBYTE), t1);

		t2 = _mm256_loadu_si256((__m256i*)(tempout + ParallelOFFSETBYTE));
		_mm256_storeu_si256((__m256i *)(output + g * ParallelBYTE + ParallelOFFSETBYTE), t2);

		break;
	case 6:
		t1 = _mm256_loadu_si256((__m256i*)(tempout));
		_mm256_storeu_si256((__m256i *)(output + g * ParallelBYTE), t1);

		t2 = _mm256_loadu_si256((__m256i*)(tempout + ParallelOFFSETBYTE));
		_mm256_storeu_si256((__m256i *)(output + g * ParallelBYTE + ParallelOFFSETBYTE), t2);

		t3 = _mm256_loadu_si256((__m256i*)(tempout + ParallelOFFSETBYTE * 2));
		_mm256_storeu_si256((__m256i *)(output + g * ParallelBYTE + ParallelOFFSETBYTE * 2), t3);
		break;


	case 1:
		t0 = _mm_loadu_si128((__m128i*)(tempout));
		_mm_storeu_si128((__m128i *)(output + g * ParallelBYTE), t0);
		break;
	case 3:
		t1 = _mm256_loadu_si256((__m256i*)(tempout));
		_mm256_storeu_si256((__m256i *)(output + g * ParallelBYTE), t1);
		t0 = _mm_loadu_si128((__m128i*)(tempout + ParallelOFFSETBYTE));
		_mm_storeu_si128((__m128i *)(output + g * ParallelBYTE + ParallelOFFSETBYTE), t0);
		break;

	case 5:
		t1 = _mm256_loadu_si256((__m256i*)(tempout));
		_mm256_storeu_si256((__m256i *)(output + g * ParallelBYTE), t1);

		t2 = _mm256_loadu_si256((__m256i*)(tempout + ParallelOFFSETBYTE));
		_mm256_storeu_si256((__m256i *)(output + g * ParallelBYTE + ParallelOFFSETBYTE), t2);
		t0 = _mm_loadu_si128((__m128i*)(tempout + ParallelOFFSETBYTE * 2));
		_mm_storeu_si128((__m128i *)(output + g * ParallelBYTE + ParallelOFFSETBYTE * 2), t0);

		break;
	case 7:
		t1 = _mm256_loadu_si256((__m256i*)(tempout));
		_mm256_storeu_si256((__m256i *)(output + g * ParallelBYTE), t1);

		t2 = _mm256_loadu_si256((__m256i*)(tempout + ParallelOFFSETBYTE * 1));
		_mm256_storeu_si256((__m256i *)(output + g * ParallelBYTE + ParallelOFFSETBYTE * 1), t2);

		t3 = _mm256_loadu_si256((__m256i*)(tempout + ParallelOFFSETBYTE * 2));
		_mm256_storeu_si256((__m256i *)(output + g * ParallelBYTE + ParallelOFFSETBYTE * 2), t3);
		t0 = _mm_loadu_si128((__m128i*)(tempout + ParallelOFFSETBYTE * 3));
		_mm_storeu_si128((__m128i *)(output + g * ParallelBYTE + ParallelOFFSETBYTE * 3), t0);


		break;
	}

}

int Crypt_Enc_Block(unsigned char *input, int in_len, unsigned char *output, int *out_len, unsigned char *key, int keylen)
{
	int i;
	u256 t1, t2, t3;
	unsigned char tempin[128] = { 0 };//  256*4/8=64
	unsigned char tempout[128] = { 0 };//  
	int g;
	unsigned char Subkey[720];
	//分组长度 不是  128bit  倍数  ，即消息长度不合格，退出
	if (in_len % BLOCKBYTE != 0) {
		printf("ERROR  消息长度不是  %d byte  倍数",BLOCKBYTE);
		return 0;
	}
	if (keylen != KEYBYTE) {
		printf("ERROR  密钥长度不是  %d byte  ",KEYBYTE);
		return 0;
	}
//	tangram_128_KeySchedule(key, Subkey);
	Key_Schedule(key, keylen,0,Subkey);
	//printSubKey(Subkey);	
	//一次处理8个分组长度  128byte
	for (g = 0; g < in_len / ParallelBYTE; g++)
	{
		tangram_128_Encrypt(input + g * ParallelBYTE, output + g * ParallelBYTE, Subkey);
	}
	//最后一个并行处理，in_len % 128不等于0，即表示最后一个并行处理 1~7个分组
	if (in_len % ParallelBYTE != 0) {

		FinalParallelIn(in_len, input + g * ParallelBYTE, tempin);

		tangram_128_Encrypt(tempin, tempout, Subkey);
		FinalParallelOut(in_len, output + g * ParallelBYTE, tempout);

	}
	*out_len = in_len;

	return 0;
}

int Crypt_Dec_Block(unsigned char *input, int in_len, unsigned char *output, int *out_len, unsigned char *key, int keylen)
{

	unsigned char tempin[128] = { 0 };//  256*4/8=64
	unsigned char tempout[128] = { 0 };//  
	int i;
	u256 t1, t2, t3;
	int g;
	unsigned char Subkey[720];
	//分组长度 不是  128bit  倍数  ，即消息长度不合格，退出
	if (in_len % BLOCKBYTE != 0) {
		printf("ERROR  消息长度不是  %d byte  倍数",BLOCKBYTE);
		return 0;
	}
	if (keylen != KEYBYTE) {
		printf("ERROR  密钥长度不是  %d byte  ",KEYBYTE);
		return 0;
	}
	
	Key_Schedule(key, keylen,1,Subkey);
	//tangram_128_KeySchedule(key, Subkey);
	//一次处理8个分组长度  128byte
	for (g = 0; g < in_len / ParallelBYTE; g++)
	{
		tangram_128_Decrypt(input + g * ParallelBYTE, output + g * ParallelBYTE, Subkey);
	}
	//最后一个并行处理，in_len % 128不等于0，即表示最后一个并行处理 1~7个分组
	if (in_len % ParallelBYTE != 0) {


		FinalParallelIn(in_len, input + g * ParallelBYTE, tempin);
		tangram_128_Decrypt(tempin, tempout, Subkey);

		FinalParallelOut(in_len, output + g * ParallelBYTE, tempout);
	}
	*out_len = in_len;

	return 0;
}

void tangram_128_Encrypt_Round(unsigned char *plain, unsigned char *cipher, unsigned char *Subkey, int cryptround)
{
	u256 w0, w1, w2, w3;
	u256 tmm0, tmm1, tmm2, tmm3, tmm4, tmm5, tmm6, tmm7, tmm8, tmm9, tmm10, tmm11;
	u256 e, f, g, h;
	int i = 0;
	u256 kmm0, kmm1, kmm2, kmm3;
	u256 all1 = _mm256_set1_epi32(0xffffffff);
	u256 ymm01, ymm13, ymm02, ymm23, ymm45, ymm57, ymm46, ymm67;

	ymm01 = _mm256_loadu_si256((__m256i *)(plain + (0 * 32)));	
	ymm23 = _mm256_loadu_si256((__m256i *)(plain + (1 * 32)));
	ymm45 = _mm256_loadu_si256((__m256i *)(plain + (2 * 32)));
	ymm67 = _mm256_loadu_si256((__m256i *)(plain + (3 * 32)));

	tmm0 = _mm256_unpacklo_epi64(ymm01, ymm23);
	tmm1 = _mm256_unpackhi_epi64(ymm01, ymm23);
	tmm2 = _mm256_unpacklo_epi64(ymm45, ymm67);
	tmm3 = _mm256_unpackhi_epi64(ymm45, ymm67);


	ymm02 = _mm256_unpacklo_epi64(tmm0, tmm2);
	ymm13 = _mm256_unpackhi_epi64(tmm0, tmm2);

	ymm46 = _mm256_unpacklo_epi64(tmm1, tmm3);
	ymm57 = _mm256_unpackhi_epi64(tmm1, tmm3);

	tmm0 = _mm256_unpacklo_epi32(ymm02, ymm13);
	tmm1 = _mm256_unpackhi_epi32(ymm02, ymm13);
	tmm2 = _mm256_unpacklo_epi32(ymm46, ymm57);
	tmm3 = _mm256_unpackhi_epi32(ymm46, ymm57);
	w0 = _mm256_unpacklo_epi64(tmm0, tmm1);
	w1 = _mm256_unpackhi_epi64(tmm0, tmm1);
	w2 = _mm256_unpacklo_epi64(tmm2, tmm3);
	w3 = _mm256_unpackhi_epi64(tmm2, tmm3);

	for (i = 0; i < cryptround; i++) {
		ROUND128_Encrypt(i);
	}
	//AddRoundKey（ARK）
	kmm0 = _mm256_set1_epi32(((u32*)Subkey)[0 + i * 4]);	
	kmm1 = _mm256_set1_epi32(((u32*)Subkey)[1 + i * 4]);	
	kmm2 = _mm256_set1_epi32(((u32*)Subkey)[2 + i * 4]);	
	kmm3 = _mm256_set1_epi32(((u32*)Subkey)[3 + i * 4]);	

	w0 = _mm256_xor_si256(w0, kmm0);
	w1 = _mm256_xor_si256(w1, kmm1);
	w2 = _mm256_xor_si256(w2, kmm2);
	w3 = _mm256_xor_si256(w3, kmm3);

	ymm02 = _mm256_unpacklo_epi64(w0, w1);
	ymm13 = _mm256_unpackhi_epi64(w0, w1);
	ymm46 = _mm256_unpacklo_epi64(w2, w3);
	ymm57 = _mm256_unpackhi_epi64(w2, w3);
	w0 = _mm256_unpacklo_epi32(ymm02, ymm46);
	w1 = _mm256_unpackhi_epi32(ymm02, ymm46);
	w2 = _mm256_unpacklo_epi32(ymm13, ymm57);
	w3 = _mm256_unpackhi_epi32(ymm13, ymm57);
	ymm02 = _mm256_unpacklo_epi32(w0, w1);
	ymm13 = _mm256_unpackhi_epi32(w0, w1);
	ymm46 = _mm256_unpacklo_epi32(w2, w3);
	ymm57 = _mm256_unpackhi_epi32(w2, w3);

	_mm256_storeu_si256((__m256i *)(cipher + (0 * 32)), ymm02);
	_mm256_storeu_si256((__m256i *)(cipher + (1 * 32)), ymm13);
	_mm256_storeu_si256((__m256i *)(cipher + (2 * 32)), ymm46);
	_mm256_storeu_si256((__m256i *)(cipher + (3 * 32)), ymm57);


}
int Crypt_Enc_Block_Round(unsigned char *input, int in_len, unsigned char *output, int *out_len, unsigned char *key, int keylen, int cryptround)
{
	int i;
	u256 t1, t2, t3;
	unsigned char tempin[128] = { 0 };//  256*4/8=64
	unsigned char tempout[128] = { 0 };//  
	int g;
	unsigned char Subkey[720];
	//分组长度 不是  128bit  倍数  ，即消息长度不合格，退出
	if (in_len % BLOCKBYTE != 0) {
		printf("ERROR  消息长度不是  %d byte  倍数",BLOCKBYTE);
		return 0;
	}
	if (keylen != KEYBYTE) {
		printf("ERROR  密钥长度不是  %d byte  ",KEYBYTE);
		return 0;
	}
	Key_Schedule(key, keylen,0,Subkey);
	//tangram_128_KeySchedule(key, Subkey);
	//一次处理8个分组长度  128byte
	for (g = 0; g < in_len / ParallelBYTE; g++)
	{
		tangram_128_Encrypt_Round(input + g * ParallelBYTE, output + g * ParallelBYTE, Subkey, cryptround);
	}
	//最后一个并行处理，in_len % 128不等于0，即表示最后一个并行处理 1~7个分组
	if (in_len % ParallelBYTE != 0) {

		FinalParallelIn(in_len, input + g * ParallelBYTE, tempin);

		tangram_128_Encrypt_Round(tempin, tempout, Subkey, cryptround);
		FinalParallelOut(in_len, output + g * ParallelBYTE, tempout);

	}
	*out_len = in_len;

	return 0;
}


int Crypt_Enc_Block_CTR(unsigned char *countIn, unsigned char *input, int in_len, unsigned char *output, int *out_len, unsigned char *key, int keylen)
{
	int i;
	u256 w0, w1, w2, w3;
	u256 t0, t1, t2, t3;
	unsigned char tempin[128] = { 0 };//  256*4/8=64
	unsigned char tempout[128] = { 0 };//  
	int g;
	unsigned char Subkey[720];
	u128 IV128;
	//分组长度 不是  128bit  倍数  ，即消息长度不合格，退出
	if (in_len % BLOCKBYTE != 0) {
		printf("ERROR  消息长度不是  %d byte  倍数",BLOCKBYTE);
		return 0;
	}
	if (keylen != KEYBYTE) {
		printf("ERROR  密钥长度不是  %d byte  ",KEYBYTE);
		return 0;
	}
	
	Key_Schedule(key, keylen,0,Subkey);
	//tangram_128_KeySchedule(key, Subkey);
	printSubKey(Subkey);	
	
	//一次处理8个分组长度  128byte  256*4  /128=8个分组  128bit   
	for (g = 0; g < in_len / ParallelBYTE; g++)
	{
		tangram_128_Encrypt(countIn+ g * ParallelBYTE, tempout, Subkey);		
		w0 = _mm256_loadu_si256((__m256i *)(tempout + (0 * 32)));		      
		w1 = _mm256_loadu_si256((__m256i *)(tempout + (1 * 32)));
		w2 = _mm256_loadu_si256((__m256i *)(tempout + (2 * 32)));
		w3 = _mm256_loadu_si256((__m256i *)(tempout + (3 * 32)));
		t0 = _mm256_loadu_si256((__m256i *)(input + g * ParallelBYTE + (0 * 32)));		      
		t1 = _mm256_loadu_si256((__m256i *)(input + g * ParallelBYTE + (1 * 32)));
		t2 = _mm256_loadu_si256((__m256i *)(input + g * ParallelBYTE + (2 * 32)));
		t3 = _mm256_loadu_si256((__m256i *)(input + g * ParallelBYTE + (3 * 32)));
		w0 = _mm256_xor_si256(w0, t0);	
		w1 = _mm256_xor_si256(w1, t1);	
		w2 = _mm256_xor_si256(w2, t2);	
		w3 = _mm256_xor_si256(w3, t3);	
		_mm256_storeu_si256((__m256i *)(output + g * ParallelBYTE + (0 * 32)), w0);
		_mm256_storeu_si256((__m256i *)(output + g * ParallelBYTE + (1 * 32)), w1);
		_mm256_storeu_si256((__m256i *)(output + g * ParallelBYTE + (2 * 32)), w2);
		_mm256_storeu_si256((__m256i *)(output + g * ParallelBYTE + (3 * 32)), w3);
	}
	//最后一个并行处理，in_len % 128不等于0，即表示最后一个并行处理 1~7个分组
	if (in_len % ParallelBYTE != 0) {

		FinalParallelIn(in_len, input + g * ParallelBYTE, tempin);

		
		tangram_128_Encrypt(countIn+ g * ParallelBYTE, tempout, Subkey);	
		w0 = _mm256_loadu_si256((__m256i *)(tempout + (0 * 32)));		      
		w1 = _mm256_loadu_si256((__m256i *)(tempout + (1 * 32)));
		w2 = _mm256_loadu_si256((__m256i *)(tempout + (2 * 32)));
		w3 = _mm256_loadu_si256((__m256i *)(tempout + (3 * 32)));
		t0 = _mm256_loadu_si256((__m256i *)(tempin + (0 * 32)));		      
		t1 = _mm256_loadu_si256((__m256i *)(tempin + (1 * 32)));
		t2 = _mm256_loadu_si256((__m256i *)(tempin + (2 * 32)));
		t3 = _mm256_loadu_si256((__m256i *)(tempin + (3 * 32)));
		w0 = _mm256_xor_si256(w0, t0);	
		w1 = _mm256_xor_si256(w1, t1);	
		w2 = _mm256_xor_si256(w2, t2);	
		w3 = _mm256_xor_si256(w3, t3);	
		_mm256_storeu_si256((__m256i *)(tempout + (0 * 32)), w0);
		_mm256_storeu_si256((__m256i *)(tempout + (1 * 32)), w1);
		_mm256_storeu_si256((__m256i *)(tempout + (2 * 32)), w2);
		_mm256_storeu_si256((__m256i *)(tempout + (3 * 32)), w3);


		FinalParallelOut(in_len, output + g * ParallelBYTE, tempout);

	}
	*out_len = in_len;
	return 0;
}
int Crypt_Dec_Block_CTR(unsigned char *countIn, unsigned char *input, int in_len, unsigned char *output, int *out_len, unsigned char *key, int keylen)
{
	int i;
	u256 w0, w1, w2, w3;
	u256 t0, t1, t2, t3;
	unsigned char tempin[128] = { 0 };//  256*4/8=64
	unsigned char tempout[128] = { 0 };//  
	int g;
	unsigned char Subkey[720];
	u128 IV128;
	//分组长度 不是  128bit  倍数  ，即消息长度不合格，退出
	if (in_len % BLOCKBYTE != 0) {
		printf("ERROR  消息长度不是  %d byte  倍数",BLOCKBYTE);
		return 0;
	}
	if (keylen != KEYBYTE) {
		printf("ERROR  密钥长度不是  %d byte  ",KEYBYTE);
		return 0;
	}
	Key_Schedule(key, keylen,0,Subkey);
	//tangram_128_KeySchedule(key, Subkey);
	//一次处理8个分组长度  128byte  256*4  /128=8个分组  128bit   
	for (g = 0; g < in_len / ParallelBYTE; g++)
	{
		tangram_128_Encrypt(countIn+ g * ParallelBYTE, tempout, Subkey);	
		w0 = _mm256_loadu_si256((__m256i *)(tempout + (0 * 32)));		      
		w1 = _mm256_loadu_si256((__m256i *)(tempout + (1 * 32)));
		w2 = _mm256_loadu_si256((__m256i *)(tempout + (2 * 32)));
		w3 = _mm256_loadu_si256((__m256i *)(tempout + (3 * 32)));
		t0 = _mm256_loadu_si256((__m256i *)(input + g * ParallelBYTE + (0 * 32)));		      
		t1 = _mm256_loadu_si256((__m256i *)(input + g * ParallelBYTE + (1 * 32)));
		t2 = _mm256_loadu_si256((__m256i *)(input + g * ParallelBYTE + (2 * 32)));
		t3 = _mm256_loadu_si256((__m256i *)(input + g * ParallelBYTE + (3 * 32)));
		w0 = _mm256_xor_si256(w0, t0);	
		w1 = _mm256_xor_si256(w1, t1);	
		w2 = _mm256_xor_si256(w2, t2);	
		w3 = _mm256_xor_si256(w3, t3);	
		_mm256_storeu_si256((__m256i *)(output + g * ParallelBYTE + (0 * 32)), w0);
		_mm256_storeu_si256((__m256i *)(output + g * ParallelBYTE + (1 * 32)), w1);
		_mm256_storeu_si256((__m256i *)(output + g * ParallelBYTE + (2 * 32)), w2);
		_mm256_storeu_si256((__m256i *)(output + g * ParallelBYTE + (3 * 32)), w3);
	}
	//最后一个并行处理，in_len % 128不等于0，即表示最后一个并行处理 1~7个分组
	if (in_len % ParallelBYTE != 0) {

		FinalParallelIn(in_len, input + g * ParallelBYTE, tempin);

		tangram_128_Encrypt(countIn+ g * ParallelBYTE, tempout, Subkey);
		w0 = _mm256_loadu_si256((__m256i *)(tempout + (0 * 32)));		      
		w1 = _mm256_loadu_si256((__m256i *)(tempout + (1 * 32)));
		w2 = _mm256_loadu_si256((__m256i *)(tempout + (2 * 32)));
		w3 = _mm256_loadu_si256((__m256i *)(tempout + (3 * 32)));
		t0 = _mm256_loadu_si256((__m256i *)(tempin + (0 * 32)));		      
		t1 = _mm256_loadu_si256((__m256i *)(tempin + (1 * 32)));
		t2 = _mm256_loadu_si256((__m256i *)(tempin + (2 * 32)));
		t3 = _mm256_loadu_si256((__m256i *)(tempin + (3 * 32)));
		w0 = _mm256_xor_si256(w0, t0);	
		w1 = _mm256_xor_si256(w1, t1);	
		w2 = _mm256_xor_si256(w2, t2);	
		w3 = _mm256_xor_si256(w3, t3);	
		_mm256_storeu_si256((__m256i *)(tempout + (0 * 32)), w0);
		_mm256_storeu_si256((__m256i *)(tempout + (1 * 32)), w1);
		_mm256_storeu_si256((__m256i *)(tempout + (2 * 32)), w2);
		_mm256_storeu_si256((__m256i *)(tempout + (3 * 32)), w3);

		FinalParallelOut(in_len, output + g * ParallelBYTE, tempout);

	}
	*out_len = in_len;
	return 0;
}
