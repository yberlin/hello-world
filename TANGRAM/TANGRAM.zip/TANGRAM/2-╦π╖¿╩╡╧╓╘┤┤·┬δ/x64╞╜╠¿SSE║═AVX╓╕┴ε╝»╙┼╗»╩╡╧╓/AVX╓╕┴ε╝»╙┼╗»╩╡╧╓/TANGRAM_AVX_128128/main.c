﻿#include"128128avx.h"
#include"timing.h"
#include"test_TimingMbps.h"
int main(){

	char *fileNameECB = "128128AVXECB2.txt";
	char *fileNameCTR = "128128AVXCTR2.txt";
	char *fileNameTiming = "cpb_128128AVXTiming.txt";
	//Test(fileNameECB, fileNameCTR);
	timing(fileNameTiming);
	//timingECB_CTR1("Mbps_128128AVXtiming1_256.txt", 15, KEYBYTE, 256);
	//timingECB_CTR1("Mbps_128128AVXtiming1_2048.txt", 15, KEYBYTE, 2048);
	//timingECB_CTR2("Mbps_128128AVXtiming2_256.txt", 15, KEYBYTE, 256);
	//timingECB_CTR2("Mbps_128128AVXtiming2_2048.txt", 15, KEYBYTE, 2048);
	return 0;
}
