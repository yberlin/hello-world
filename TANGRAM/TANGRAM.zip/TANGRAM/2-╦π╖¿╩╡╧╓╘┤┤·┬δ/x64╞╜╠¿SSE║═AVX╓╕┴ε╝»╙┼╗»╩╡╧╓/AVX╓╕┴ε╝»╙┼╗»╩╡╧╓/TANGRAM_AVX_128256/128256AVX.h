﻿#include <stdio.h>
#include <memory.h>
#include <time.h>
#include <stdlib.h>
#include <malloc.h>

#include <emmintrin.h>//sse2 header file(include sse header file)  
#include <pmmintrin.h> //SSE3(include emmintrin.h)  
#include <tmmintrin.h>//SSSE3(include pmmintrin.h)  
#include <smmintrin.h>//SSE4.1(include tmmintrin.h)  
#include <nmmintrin.h>//SSE4.2(include smmintrin.h)  
#include <immintrin.h>
#include <xmmintrin.h>
#include <wmmintrin.h>
typedef unsigned char u8;
typedef unsigned int u32;
typedef unsigned long long u64;
//typedef unsigned __int64 u64;
typedef __m256i u256;
typedef __m128i u128;


#define KEYBYTE   32//
//#define KEYBIT   256//
#define ParallelBYTE  128//  256*4/8=128
#define BLOCKBYTE   16//128/8=16
#define ParallelOFFSETBYTE   32// 256/8=32
#define ROUNDNUM  50
/** @brief Tangram的ShiftRow的第1行的行移位参数 */
#define ROL32_1  1
/** @brief Tangram的ShiftRow的第2行的行移位参数 */
#define ROL32_2 8
/** @brief Tangram的ShiftRow的第3行的行移位参数 */
#define ROL32_3 11
#define rol32(x, n)   (((x) << ((int)((n) & 0x1f))) | ((x) >> ((int)((32 - ((n) & 0x1f))))) & 0xffffffff) 


/** @brief TANGRAM-128 的密钥状态的4个分支的8列经过S盒变换 */
#define key128_sbox(k0, k1, k2, k3)                                    \
{                                                                      \
	t1 = k0 ^ k2;                                                      \
	t2 = k0 & k1;                                                      \
	t3 = k3 ^ t2;                                                      \
	g = k2 ^ t3;                                                       \
	t5 = k1 ^ k2;                                                      \
	t6 = t1 & t3;                                                      \
	e = t5 ^ t6;                                                       \
	t8 = k1 | k3;                                                      \
	t9 = t1 ^ t8;                                                      \
	h = ~t9;                                                           \
	t11 = t5 & t9;                                                     \
	f = t3 ^ t11;                                                      \
	k0 = e;                                                            \
	k1 = f;                                                            \
	k2 = g;                                                            \
	k3 = h;                                                            \
}

/** @brief TANGRAM-128 的密钥编排的一轮4-分支Feistel变换 */
//这里没有进行feistel移位
#define key128_rol(k0, k1, k2, k3)                                     \
{                                                                      \
	t0 = rol32(k0, 7);				                               \
	t1 = rol32(k2, 17);				                               \
	k1 ^= t0;						                                   \
	k3 ^= t1; 					                                       \
}
/** @brief TANGRAM 128/256 的密钥编排的一轮*/

//生成r+2轮密钥，w0-w3表示r+1轮密钥，w4-w7表示r轮密钥
#define key128_round(w0, w1, w2, w3, w4, w5, w6, w7, n)                \
{                                                                      \
	u32 k8, k9, k10, k11;                                              \
	k8=w0;                                                             \
	k9=w1;                                                             \
	k10=w2;                                                            \
	k11=w3;                                                            \
	key128_sbox(k8, k9, k10, k11);                                     \
	key128_rol(k8, k9, k10, k11);                                      \
	k9 ^= RC[n];                                                     \
	w4 ^=k9;                                                           \
	w5 ^=k10;                                                          \
	w6 ^=k11;                                                          \
	w7 ^=k8;                                                           \
	*(u32*)subkey = k0;subkey += 4;\
	*(u32*)subkey = k1;subkey += 4;\
	*(u32*)subkey = k2;subkey += 4;\
	*(u32*)subkey = k3;subkey += 4;\
}

#define forward_round128_sbox_8block(w0, w1, w2, w3)  \
{                   \
	tmm1 =_mm256_xor_si256(  w0  , w2    );	\
	tmm2 =_mm256_and_si256(  w0  , w1    );	\
	tmm3 =_mm256_xor_si256(  w3  , tmm2  );	\
	g    =_mm256_xor_si256(  w2  , tmm3  );	\
	tmm5 =_mm256_xor_si256(  w1  , w2    );	\
	tmm6 =_mm256_and_si256(  tmm1, tmm3  );	\
	e    =_mm256_xor_si256(  tmm5, tmm6  );	\
	tmm8 =_mm256_or_si256 (  w1  , w3    );	\
	tmm9 =_mm256_xor_si256(  tmm1, tmm8  );	\
	h    =_mm256_xor_si256(  tmm9 , all1 );	\
	tmm11=_mm256_and_si256(  tmm5, tmm9  );	\
	f    =_mm256_xor_si256(  tmm3, tmm11 );	\
	w0 = e;  	\
	w1 = f; 	\
	w2 = g; 	\
	w3 = h;  	\
}
#define ROUND128_Encrypt(i) {\
	/*AddRoundKey（ARK）*/\
	kmm0 = _mm256_set1_epi32(((u32*)Subkey)[0+i*4]);	\
	kmm1 = _mm256_set1_epi32(((u32*)Subkey)[1+i*4]);	\
	kmm2 = _mm256_set1_epi32(((u32*)Subkey)[2+i*4]);	\
	kmm3 = _mm256_set1_epi32(((u32*)Subkey)[3+i*4]);	\
	w0 = _mm256_xor_si256(w0, kmm0);	\
	w1 = _mm256_xor_si256(w1, kmm1);	\
	w2 = _mm256_xor_si256(w2, kmm2);	\
	w3 = _mm256_xor_si256(w3, kmm3);	\
	/*SubColumn（SC）*/\
	forward_round128_sbox_8block(w0, w1, w2, w3); \
	/*ShiftRow（SR）*/\
	w1 = _mm256_or_si256(_mm256_slli_epi32(w1,  ROL32_1), _mm256_srli_epi32(w1, 32 - ROL32_1));    \
	w2 = _mm256_or_si256(_mm256_slli_epi32(w2,  ROL32_2), _mm256_srli_epi32(w2, 32 - ROL32_2));     \
	w3 = _mm256_or_si256(_mm256_slli_epi32(w3,  ROL32_3), _mm256_srli_epi32(w3, 32 - ROL32_3));   \
}

#define invert_round128_sbox_8block(w0, w1, w2, w3)  \
{                   \
	tmm1 =_mm256_xor_si256(  w3  , all1  );	\
	tmm2 =_mm256_and_si256(  w0  , tmm1  );	\
	tmm3 =_mm256_xor_si256(  w1  , tmm2  );	\
	g    =_mm256_xor_si256(  w2  , tmm3  );	\
	tmm5 =_mm256_xor_si256(  w0  , w2    );	\
	tmm6 =_mm256_and_si256(  tmm1, tmm3  );	\
	f    =_mm256_xor_si256(  tmm5, tmm6  );	\
	tmm8 =_mm256_xor_si256(  w0  , tmm1  );	\
	tmm9 =_mm256_and_si256(  tmm3, tmm5  );	\
	e    =_mm256_xor_si256(  tmm8, tmm9  );	\
	tmm11=_mm256_and_si256(  f   , e      );	\
	h    =_mm256_xor_si256(  tmm3, tmm11 );	\
	w0 = e;  	\
	w1 = f; 	\
	w2 = g; 	\
	w3 = h;  	\
}
/*
*/
#define ROUND128_Decrypt(i) {\
	/*AddRoundKey（ARK）*/\
	kmm0 = _mm256_set1_epi32(((u32*)Subkey)[0+i*4]);	\
	kmm1 = _mm256_set1_epi32(((u32*)Subkey)[1+i*4]);	\
	kmm2 = _mm256_set1_epi32(((u32*)Subkey)[2+i*4]);	\
	kmm3 = _mm256_set1_epi32(((u32*)Subkey)[3+i*4]);	\
	w0 = _mm256_xor_si256(w0, kmm0);	\
	w1 = _mm256_xor_si256(w1, kmm1);	\
	w2 = _mm256_xor_si256(w2, kmm2);	\
	w3 = _mm256_xor_si256(w3, kmm3);	\
	/*ShiftRow（SR）*/\
	w1 = _mm256_or_si256(_mm256_srli_epi32(w1,  ROL32_1), _mm256_slli_epi32(w1, 32 - ROL32_1));    \
	w2 = _mm256_or_si256(_mm256_srli_epi32(w2,  ROL32_2), _mm256_slli_epi32(w2, 32 - ROL32_2));     \
	w3 = _mm256_or_si256(_mm256_srli_epi32(w3,  ROL32_3), _mm256_slli_epi32(w3, 32 - ROL32_3));   \
	/*SubColumn（SC）*/\
	invert_round128_sbox_8block(w0, w1, w2, w3); \
}


#define PRINTBLOCKTXT
#define PRINTSubKeyTXT
//#define PRINTSubKey
//#define PRINTSTATE
//#define PRINTBLOCK
void printBLOCK(const char* str, u8 *s, int len) ;
void printSubKey(u8 *Subkey);
void printBLOCKTXT(FILE *fp, const char* str, u8 *s, int len);

void printSubKeyTXT(FILE *fp, u8 *Subkey) ;

int Key_Schedule(unsigned char * seedkey,int keylen,int direction,unsigned char * subkey);
//void tangram_256_KeySchedule(unsigned char *Seedkey, unsigned char *Subkey) ;
void printBLOCK(const char* str, u8 *s, int len);
void tangram_128_Encrypt(unsigned char *plain, unsigned char *cipher, unsigned char *Subkey);
void tangram_128_Decrypt(unsigned char *cipher, unsigned char *plain, unsigned char *Subkey);
void FinalParallelIn(int in_len,unsigned char *input,unsigned char* tempin);
void FinalParallelOut(int in_len,unsigned char *output,unsigned char* tempout);
int Crypt_Enc_Block(unsigned char *input, int in_len, unsigned char *output, int *out_len, unsigned char *key, int keylen);

int Crypt_Dec_Block(unsigned char *input, int in_len, unsigned char *output, int *out_len, unsigned char *key, int keylen);
void tangram_128_Encrypt_Round(unsigned char *plain, unsigned char *cipher, unsigned char *Subkey,int cryptround);
int Crypt_Enc_Block_Round(unsigned char *input, int in_len, unsigned char *output, int *out_len, unsigned char *key, int keylen,int cryptround);
int Crypt_Enc_Block_CTR(unsigned char *countIV, unsigned char *input, int in_len, unsigned char *output, int *out_len, unsigned char *key, int keylen);
int Crypt_Dec_Block_CTR(unsigned char *countIV, unsigned char *input, int in_len, unsigned char *output, int *out_len, unsigned char *key, int keylen);

#define loopNum 2000