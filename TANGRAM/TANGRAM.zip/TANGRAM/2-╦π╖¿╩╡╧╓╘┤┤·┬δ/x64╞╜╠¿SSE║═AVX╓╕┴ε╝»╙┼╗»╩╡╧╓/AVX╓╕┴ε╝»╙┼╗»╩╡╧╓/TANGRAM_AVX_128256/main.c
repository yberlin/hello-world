﻿#include"128256AVX.h"

#include"CTR128.h"
int main(){


	//AVX实现  256*4/128=8   8个分组并行实现

	u8 testplain[256] = { 0 }, testplain1[256] = { 0 };
	u8 testcipher[256] = { 0 };
	int i, j;
	int in_len = 256, output = 0;
	unsigned char plain[128] = { 0 };
	u8 cipher[128] = { 0 };
	u8 plain1[128] = { 0 };
	u128 IV128;
	u8 countIn[144] = { 0 };
	u8 Subkey[816];
	unsigned char Seedkey[32] = {
		0xf,0xf,0xf,0xf,
		2,2,2,2,
		3,3,3,3,
		0xf,0xf,0xf,0xf,
	};

	////////////////////ECB
	for (j = 0; j < KEYBYTE; j++) {
		Seedkey[j] = 0;
	}
	
	Key_Schedule(Seedkey, KEYBYTE,0,Subkey);
	printSubKey(Subkey);

	plain[BLOCKBYTE - 1] = 0;
	plain[2 * BLOCKBYTE - 1] = 1;
	plain[3 * BLOCKBYTE - 1] = 2;
	plain[4 * BLOCKBYTE - 1] = 3;
	plain[5 * BLOCKBYTE - 1] = 4;
	plain[6 * BLOCKBYTE - 1] = 5;
	plain[7 * BLOCKBYTE - 1] = 6;
	plain[8 * BLOCKBYTE - 1] = 7;
	
	for (i = 8; i < 16; i++) {
		for (j = 0; j < BLOCKBYTE; j++) {
			testplain[BLOCKBYTE * i + j] = BLOCKBYTE * (i-8) + j;
		}
	}
	tangram_128_Encrypt(plain, cipher, Subkey);
	printBLOCK("Seedkey", Seedkey, KEYBYTE);
	printBLOCK("tangram_128_Encrypt \nplain", plain, ParallelBYTE);
	printBLOCK("cipher", cipher, ParallelBYTE);
	tangram_128_Decrypt(cipher, plain1, Subkey);
	printBLOCK("tangram_128_Decrypt\nSeedkey", Seedkey, KEYBYTE);
	printBLOCK("cipher", cipher, ParallelBYTE);
	printBLOCK("plain", plain1, ParallelBYTE);
	
	for (j = 0; j < KEYBYTE; j++) {
		Seedkey[j] = 0;
	}
	
	Key_Schedule(Seedkey, KEYBYTE,0,Subkey);
	printSubKey(Subkey);
	printBLOCK("Seedkey", Seedkey, KEYBYTE);
	
	testplain[BLOCKBYTE - 1] = 0;
	testplain[2 * BLOCKBYTE - 1] = 1;
	testplain[3 * BLOCKBYTE - 1] = 2;
	testplain[4 * BLOCKBYTE - 1] = 3;
	testplain[5 * BLOCKBYTE - 1] = 4;
	testplain[6 * BLOCKBYTE - 1] = 5;
	testplain[7 * BLOCKBYTE - 1] = 6;
	testplain[8 * BLOCKBYTE - 1] = 7;
	for (in_len = BLOCKBYTE; in_len <= 256; in_len += BLOCKBYTE) {

		Crypt_Enc_Block(testplain, in_len, testcipher, &output, Seedkey, KEYBYTE);

		printBLOCK("Crypt_Enc_Block----\ntestplain", testplain, in_len);
		printBLOCK("testcipher", testcipher, output);
		Crypt_Dec_Block(testcipher, in_len, testplain1, &output, Seedkey, KEYBYTE);

		printBLOCK("Crypt_Dec_Block\ntestcipher", testcipher, in_len);
		printBLOCK("testplain1", testplain1, output);

	}
	//////////////////////////////
	printf("\n---------**-test CTR  %d个分组并行 tangram_128_Encrypt tangram_128_Decrypt ----------------\n", ParallelBYTE / BLOCKBYTE);
	for (i = 8; i < 16; i++) {
		for (j = 0; j < BLOCKBYTE; j++) {
			testplain[BLOCKBYTE * i + j] = BLOCKBYTE * (i-8) + j;
		}
	}
	for (j = 0; j < KEYBYTE; j++) {
		Seedkey[j] = 0;
	}
	
	Key_Schedule(Seedkey, KEYBYTE,0,Subkey);
	//tangram_256_KeySchedule(Seedkey, Subkey);
	printSubKey(Subkey);


	
	testplain[BLOCKBYTE - 1] = 0;
	testplain[2 * BLOCKBYTE - 1] = 1;
	testplain[3 * BLOCKBYTE - 1] = 2;
	testplain[4 * BLOCKBYTE - 1] = 3;
	testplain[5 * BLOCKBYTE - 1] = 4;
	testplain[6 * BLOCKBYTE - 1] = 5;
	testplain[7 * BLOCKBYTE - 1] = 6;
	testplain[8 * BLOCKBYTE - 1] = 7;
	for (in_len = BLOCKBYTE; in_len <= 256; in_len += BLOCKBYTE) {
		printf("---------**-in_len=%d  %d个分组----------------\n", in_len, in_len / BLOCKBYTE);
		Crypt_Enc_Block_CTR(countINIV8, testplain, in_len, testcipher, &output, Seedkey, KEYBYTE);

		printBLOCK("Crypt_Enc_Block----\ntestplain", testplain, in_len);
		printBLOCK("testcipher", testcipher, output);
		Crypt_Dec_Block_CTR(countINIV8, testcipher, in_len, testplain1, &output, Seedkey, KEYBYTE);

		printBLOCK("Crypt_Dec_Block\ntestcipher", testcipher, in_len);
		printBLOCK("testplain1", testplain1, output);
	}
	
return 0;
}
