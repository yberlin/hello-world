﻿#include "256256SSE.h"

u32 RC[82] = { 0x1,0x2,0x4,0x8,0x10,0x20,0x41,0x3,0x6,0xc,0x18,0x30,0x61,0x42,0x5,0xa,0x14,0x28,0x51,
	0x23,0x47,0xf,0x1e,0x3c,0x79,0x72,0x64,0x48,0x11,0x22,0x45,0xb,0x16,0x2c,0x59,0x33,0x67,0x4e,0x1d,
	0x3a,0x75,0x6a,0x54,0x29,0x53,0x27,0x4f,0x1f,0x3e,0x7d,0x7a,0x74,0x68,0x50,0x21,0x43,0x7,0xe,0x1c,
	0x38,0x71,0x62,0x44,0x9,0x12,0x24,0x49,0x13,0x26,0x4d,0x1b,0x36,0x6d,0x5a,0x35,0x6b,0x56,0x2d,0x5b,0x37,0x6f,0x5e, };

void printBLOCKTXT(FILE *fp, const char* str, u8 *s, int len) {
#ifdef PRINTBLOCKTXT
	int i, j;
	fprintf(fp, "%-9s   :\n", str);
	for (i = 0; i < len; i++) {
		fprintf(fp, "%02x,", s[i]);
		if (i % 16 == 15)
			fprintf(fp, "\n");
	}
	fprintf(fp, "\n");
#endif
}

void printSubKeyTXT(FILE *fp, u8 *Subkey) {
#ifdef PRINTSubKeyTXT
	int i, j;
	fprintf(fp, "SubKey:\n");
	for (j = 0; j < 83; j++) {
		fprintf(fp, "%-3d ：", j);
		for (i = 0; i < 16; i++) {
			fprintf(fp, "%02x", Subkey[j * 16 + i]);
		}
		fprintf(fp, "\n");
	}
#endif
}
void printStateSubkey(unsigned char *str, u64 k0, u64 k1, u64 k2, u64 k3)
{
#ifdef PRINTSubKey
	printf("%-9s:\n", str);
	printf("%016llx,", k0);
	printf("%016llx,", k1);
	printf("%016llx,", k2);
	printf("%016llx\n", k3);
#endif
}
void printSubKey(u8 *Subkey) {
#ifdef PRINTSubKey
	int i, j;
	for (j = 0; j < 83; j++) {
		printf("%d ：\n", j);
		for (i = 0; i < 32; i++) {
			printf("%02x", Subkey[j*32+i]);
		}
		printf("\n");
	}
#endif
}
void printBLOCK(const char* str, u8 *s, int len) {
#ifdef PRINTBLOCK
	int i;
	printf("%-9s   :\n", str);
	for (i = 0; i < len; i++) {
		printf("%02x,", s[i]);
		if (i % 32 == 31)
			printf("\n");
	}
	printf("\n");
#endif
}
int Key_Schedule(unsigned char * seedkey,int keylen,int direction,unsigned char * subkey){
	u64 k0, k1, k2, k3;
	u64 t0, t1, t2, t3, t4, t5, t6, t7, t8, t9, t10, t11;
	u64 e, f, g, h;
	u64 tmp =0;
	int i;
	
	if (keylen != KEYBYTE) {
		printf("ERROR  密钥长度不是  %d byte  ",KEYBYTE);
		return 0;
	}
	//生成第一轮初始密钥
	k0 = ((u64*)seedkey)[0];
	k1 = ((u64*)seedkey)[1];
	k2 = ((u64*)seedkey)[2];
	k3 = ((u64*)seedkey)[3];
	for (i = 0; i < ROUNDNUM; i++) {
		//Subkey
		((u64*)subkey)[0] = k0;
		((u64*)subkey)[1] = k1;
		((u64*)subkey)[2] = k2;
		((u64*)subkey)[3] = k3;
		subkey += 32;
		//		printStateSubkey("     sbox in", k0, k1, k2, k3);
		key256_sbox(k0, k1, k2, k3);
		//		printStateSubkey("     rol in", k0, k1, k2, k3);
		key256_rol(k0, k1, k2, k3);
		//		printStateSubkey("     RC in", k0, k1, k2, k3);
		k1 ^= RC[i];
		//		printStateSubkey("end", k0, k1, k2, k3);
		tmp = k0; k0 = k1; k1 = k2; k2 = k3; k3 = tmp;
	}
	((u64*)subkey)[0] = k0;
	((u64*)subkey)[1] = k1;
	((u64*)subkey)[2] = k2;
	((u64*)subkey)[3] = k3;
	subkey += 32;
}


void tangram_256_Encrypt(unsigned char *plain, unsigned char *cipher, unsigned char *Subkey)
{
	u128 w0, w1, w2, w3;
	u128 tmm0, tmm1, tmm2, tmm3, tmm4, tmm5, tmm6, tmm7, tmm8, tmm9, tmm10, tmm11;
	u128 e, f, g, h;
	int i = 0;
	u128 kmm0, kmm1, kmm2, kmm3;

	u128 xmm01, xmm13, xmm02, xmm23, xmm45, xmm57, xmm46, xmm67;
	u128 all1 = _mm_set1_epi32(0xffffffff);
	xmm01 = _mm_loadu_si128((__m128i *)(plain + (0 * 16)));
	xmm23 = _mm_loadu_si128((__m128i *)(plain + (1 * 16)));
	xmm45 = _mm_loadu_si128((__m128i *)(plain + (2 * 16)));
	xmm67 = _mm_loadu_si128((__m128i *)(plain + (3 * 16)));
	/*	print128_2("xmm01", xmm01);
	print128_2("xmm23", xmm23);
	print128_2("xmm45", xmm45);
	print128_2("xmm67", xmm67);*/
	w0 = _mm_unpacklo_epi64(xmm01, xmm45);
	w1 = _mm_unpackhi_epi64(xmm01, xmm45);
	w2 = _mm_unpacklo_epi64(xmm23, xmm67);
	w3 = _mm_unpackhi_epi64(xmm23, xmm67);
	/*
	print128_2("w0", w0);
	print128_2("w1", w1);
	print128_2("w2", w2);
	print128_2("w3", w3); 
	*/
	for (i = 0; i < ROUNDNUM; i++) {
		//		printState(i, w0, w1, w2, w3);
		ROUND256_Encrypt(i)
	}
	/*AddRoundKey（ARK）*/
	kmm0 = _mm_set1_epi64(((__m64*)Subkey)[0+i*4]);	\
		kmm1 = _mm_set1_epi64(((__m64*)Subkey)[1+i*4]);	\
		kmm2 = _mm_set1_epi64(((__m64*)Subkey)[2+i*4]);	\
		kmm3 = _mm_set1_epi64(((__m64*)Subkey)[3+i*4]);	\
		w0 = _mm_xor_si128(w0, kmm0);	
	w1 = _mm_xor_si128(w1, kmm1);	
	w2 = _mm_xor_si128(w2, kmm2);	
	w3 = _mm_xor_si128(w3, kmm3);	

	xmm01 = _mm_unpacklo_epi64(w0, w1);
	xmm45 = _mm_unpackhi_epi64(w0, w1);
	xmm23 = _mm_unpacklo_epi64(w2, w3);
	xmm67 = _mm_unpackhi_epi64(w2, w3);
	//	printState(i, w0, w1, w2, w3);
	_mm_storeu_si128((__m128i *)(cipher + (0 * 16)), xmm01);
	_mm_storeu_si128((__m128i *)(cipher + (1 * 16)), xmm23);
	_mm_storeu_si128((__m128i *)(cipher + (2 * 16)), xmm45);
	_mm_storeu_si128((__m128i *)(cipher + (3 * 16)), xmm67);
}
void tangram_256_Decrypt(unsigned char *cipher, unsigned char *plain, unsigned char *Subkey)
{
	u128 w0, w1, w2, w3;
	u128 tmm0, tmm1, tmm2, tmm3, tmm4, tmm5, tmm6, tmm7, tmm8, tmm9, tmm10, tmm11;
	u128 e, f, g, h;
	int i = 0,j;
	u128 kmm0, kmm1, kmm2, kmm3;

	u128 xmm01, xmm13, xmm02, xmm23, xmm45, xmm57, xmm46, xmm67;
	u128 all1 = _mm_set1_epi32(0xffffffff);

	xmm01 = _mm_loadu_si128((__m128i*)(cipher + 0 * 16));
	xmm23 = _mm_loadu_si128((__m128i*)(cipher + 1 * 16));
	xmm45 = _mm_loadu_si128((__m128i*)(cipher + 2 * 16));
	xmm67 = _mm_loadu_si128((__m128i*)(cipher + 3 * 16));
	/*
	print128_2("xmm01", xmm01);
	print128_2("xmm23", xmm23);
	print128_2("xmm45", xmm45);
	print128_2("xmm67", xmm67);
	*/
	w0 = _mm_unpacklo_epi64(xmm01, xmm45);
	w1 = _mm_unpackhi_epi64(xmm01, xmm45);
	w2 = _mm_unpacklo_epi64(xmm23, xmm67);
	w3 = _mm_unpackhi_epi64(xmm23, xmm67);
	/*
	print128_2("w0", w0);
	print128_2("w1", w1);
	print128_2("w2", w2);
	print128_2("w3", w3); 
	*/
	printSubKey(Subkey);
	for (i = ROUNDNUM; i > 0; i--) {
		ROUND256_Decrypt(i);
	}
	/*AddRoundKey（ARK）*/
	kmm0 = _mm_set1_epi64(((__m64*)Subkey)[0+i*4]);	\
		kmm1 = _mm_set1_epi64(((__m64*)Subkey)[1+i*4]);	\
		kmm2 = _mm_set1_epi64(((__m64*)Subkey)[2+i*4]);	\
		kmm3 = _mm_set1_epi64(((__m64*)Subkey)[3+i*4]);	\
		w0 = _mm_xor_si128(w0, kmm0);	\
		w1 = _mm_xor_si128(w1, kmm1);	\
		w2 = _mm_xor_si128(w2, kmm2);	\
		w3 = _mm_xor_si128(w3, kmm3);	\

		xmm01 = _mm_unpacklo_epi64(w0, w1);
	xmm45 = _mm_unpackhi_epi64(w0, w1);
	xmm23 = _mm_unpacklo_epi64(w2, w3);
	xmm67 = _mm_unpackhi_epi64(w2, w3);
	//	printState(i, w0, w1, w2, w3);
	_mm_storeu_si128((__m128i *)(plain + (0 * 16)), xmm01);
	_mm_storeu_si128((__m128i *)(plain + (1 * 16)), xmm23);
	_mm_storeu_si128((__m128i *)(plain + (2 * 16)), xmm45);
	_mm_storeu_si128((__m128i *)(plain + (3 * 16)), xmm67);
}

int Crypt_Enc_Block(unsigned char *input, int in_len, unsigned char *output, int *out_len, unsigned char *key, int keylen)
{
	u128 t1,t2;
	int g;
	unsigned char tempin[64]={0};//  128*4/8=64
	unsigned char tempout[64]={0};//  128*4/8=64
	unsigned char Subkey[2656] = { 0 };//83*32=   Subkey[83][32]
	//分组长度 不是  256bit  倍数  ，即消息长度不合格，退出
	if (in_len % BLOCKBYTE != 0) {//分组长度为  256比特  32BYTE
		printf("ERROR  消息长度不是  %d byte  倍数",BLOCKBYTE);
		return 0;
	}
	if (keylen != KEYBYTE) {
		printf("ERROR  密钥长度不是  %d byte  ",KEYBYTE);
		return 0;
	}
	Key_Schedule(key, keylen,0,Subkey);
	printSubKey(Subkey);
	//一次处理  128*4bit  64 BYTE数据
	for (g = 0; g < in_len / ParallelBYTE; g++)
	{
		tangram_256_Encrypt(input + g * ParallelBYTE, output + g * ParallelBYTE, Subkey);
	}
	if (in_len % ParallelBYTE != 0) {

		t1 = _mm_loadu_si128((__m128i*)(input + g * ParallelBYTE));
		_mm_storeu_si128((__m128i *)(tempin), t1);
		t2 = _mm_loadu_si128((__m128i*)(input + g * ParallelBYTE + ParallelOFFSETBYTE));
		_mm_storeu_si128((__m128i *)(tempin+ParallelOFFSETBYTE), t2);
		//tangram_256_Decrypt(input + g * 64, output + g * 64, Subkey);
		tangram_256_Encrypt(tempin, tempout, Subkey);
		//output + g * 64=temp;
		t1 = _mm_loadu_si128((__m128i*)(tempout));
		_mm_storeu_si128((__m128i *)(output + g * ParallelBYTE), t1);
		t2 = _mm_loadu_si128((__m128i*)(tempout + ParallelOFFSETBYTE));
		_mm_storeu_si128((__m128i *)(output + g * ParallelBYTE+ParallelOFFSETBYTE), t2);


	}
	*out_len = in_len;

	return 0;
}

int Crypt_Dec_Block(unsigned char *input, int in_len, unsigned char *output, int *out_len, unsigned char *key, int keylen)
{
	u128 t1,t2;
	int g;
	unsigned char tempin[64]={0};//  128*4/8=64
	unsigned char tempout[64]={0};//  128*4/8=64
	unsigned char Subkey[2656] = { 0 };//83*32=   Subkey[83][32]
	//分组长度 不是  128bit  倍数  ，即消息长度不合格，退出
	if (in_len % BLOCKBYTE != 0) {//分组长度为  256比特  32BYTE
		printf("ERROR  消息长度不是  %d byte  倍数",BLOCKBYTE);
		return 0;
	}
	if (keylen != KEYBYTE) {
		printf("ERROR  密钥长度不是  %d byte  ",KEYBYTE);
		return 0;
	}
	Key_Schedule(key, keylen,0,Subkey);

	printSubKey(Subkey);
	//一次处理  128*4bit  64 BYTE数据
	for (g = 0; g < in_len / ParallelBYTE; g++)
	{
		tangram_256_Decrypt(input + g * ParallelBYTE, output + g * ParallelBYTE, Subkey);
	}
	//最后一个并行处理，分组长度必须为 256bit/ 32Byte  的倍数，并且in_len % 64不等于0，即表示最后一个并行处理 1个分组
	if (in_len % 64 != 0) {

		t1 = _mm_loadu_si128((__m128i*)(input + g * ParallelBYTE));
		_mm_storeu_si128((__m128i *)(tempin), t1);
		t2 = _mm_loadu_si128((__m128i*)(input + g * ParallelBYTE + ParallelOFFSETBYTE));
		_mm_storeu_si128((__m128i *)(tempin+ParallelOFFSETBYTE), t2);
		//tangram_256_Decrypt(input + g * 64, output + g * 64, Subkey);
		tangram_256_Decrypt(tempin, tempout, Subkey);
		//output + g * 64=temp;
		t1 = _mm_loadu_si128((__m128i*)(tempout));
		_mm_storeu_si128((__m128i *)(output + g * ParallelBYTE), t1);
		t2 = _mm_loadu_si128((__m128i*)(tempout + ParallelOFFSETBYTE));
		_mm_storeu_si128((__m128i *)(output + g * ParallelBYTE+ParallelOFFSETBYTE), t2);
	}
	*out_len = in_len ;

	return 0;
}

void tangram_256_Encrypt_Round(unsigned char *plain, unsigned char *cipher, unsigned char *Subkey,int cryptround)
{
	u128 w0, w1, w2, w3;
	u128 tmm0, tmm1, tmm2, tmm3, tmm4, tmm5, tmm6, tmm7, tmm8, tmm9, tmm10, tmm11;
	u128 e, f, g, h;
	int i = 0;
	u128 kmm0, kmm1, kmm2, kmm3;

	u128 xmm01, xmm13, xmm02, xmm23, xmm45, xmm57, xmm46, xmm67;
	u128 all1 = _mm_set1_epi32(0xffffffff);
	xmm01 = _mm_loadu_si128((__m128i *)(plain + (0 * 16)));
	xmm23 = _mm_loadu_si128((__m128i *)(plain + (1 * 16)));
	xmm45 = _mm_loadu_si128((__m128i *)(plain + (2 * 16)));
	xmm67 = _mm_loadu_si128((__m128i *)(plain + (3 * 16)));
	w0 = _mm_unpacklo_epi64(xmm01, xmm45);
	w1 = _mm_unpackhi_epi64(xmm01, xmm45);
	w2 = _mm_unpacklo_epi64(xmm23, xmm67);
	w3 = _mm_unpackhi_epi64(xmm23, xmm67);
	for (i = 0; i < cryptround; i++) {
		ROUND256_Encrypt(i)
	}
	/*AddRoundKey（ARK）*/
	kmm0 = _mm_set1_epi64(((__m64*)Subkey)[0+i*4]);	\
		kmm1 = _mm_set1_epi64(((__m64*)Subkey)[1+i*4]);	\
		kmm2 = _mm_set1_epi64(((__m64*)Subkey)[2+i*4]);	\
		kmm3 = _mm_set1_epi64(((__m64*)Subkey)[3+i*4]);	\
		w0 = _mm_xor_si128(w0, kmm0);	
	w1 = _mm_xor_si128(w1, kmm1);	
	w2 = _mm_xor_si128(w2, kmm2);	
	w3 = _mm_xor_si128(w3, kmm3);	

	xmm01 = _mm_unpacklo_epi64(w0, w1);
	xmm45 = _mm_unpackhi_epi64(w0, w1);
	xmm23 = _mm_unpacklo_epi64(w2, w3);
	xmm67 = _mm_unpackhi_epi64(w2, w3);
	_mm_storeu_si128((__m128i *)(cipher + (0 * 16)), xmm01);
	_mm_storeu_si128((__m128i *)(cipher + (1 * 16)), xmm23);
	_mm_storeu_si128((__m128i *)(cipher + (2 * 16)), xmm45);
	_mm_storeu_si128((__m128i *)(cipher + (3 * 16)), xmm67);
}

int Crypt_Enc_Block_Round(unsigned char *input, int in_len, unsigned char *output, int *out_len, unsigned char *key, int keylen,int cryptround)
{

	u128 t1,t2;
	int g;
	unsigned char tempin[64]={0};//  128*4/8=64
	unsigned char tempout[64]={0};//  128*4/8=64
	unsigned char Subkey[2656] = { 0 };//83*32=   Subkey[83][32]
	//分组长度 不是  256bit  倍数  ，即消息长度不合格，退出
	if (in_len % BLOCKBYTE != 0) {//分组长度为  256比特  32BYTE
		printf("ERROR  消息长度不是  %d byte  倍数",BLOCKBYTE);
		return 0;
	}
	if (keylen != KEYBYTE) {
		printf("ERROR  密钥长度不是  %d byte  ",KEYBYTE);
		return 0;
	}
	Key_Schedule(key, keylen,0,Subkey);

	printSubKey(Subkey);
	//一次处理  128*4bit  64 BYTE数据
	for (g = 0; g < in_len / ParallelBYTE; g++)
	{
		tangram_256_Encrypt_Round(input + g * ParallelBYTE, output + g * ParallelBYTE, Subkey,cryptround);
	}
	if (in_len % ParallelBYTE != 0) {

		t1 = _mm_loadu_si128((__m128i*)(input + g * ParallelBYTE));
		_mm_storeu_si128((__m128i *)(tempin), t1);
		t2 = _mm_loadu_si128((__m128i*)(input + g * ParallelBYTE + ParallelOFFSETBYTE));
		_mm_storeu_si128((__m128i *)(tempin+ParallelOFFSETBYTE), t2);
		//tangram_256_Decrypt(input + g * 64, output + g * 64, Subkey);
		tangram_256_Encrypt_Round(tempin, tempout, Subkey,cryptround);
		//output + g * 64=temp;
		t1 = _mm_loadu_si128((__m128i*)(tempout));
		_mm_storeu_si128((__m128i *)(output + g * ParallelBYTE), t1);
		t2 = _mm_loadu_si128((__m128i*)(tempout + ParallelOFFSETBYTE));
		_mm_storeu_si128((__m128i *)(output + g * ParallelBYTE+ParallelOFFSETBYTE), t2);


	}
	*out_len = in_len;

	return 0;

}

int Crypt_Enc_Block_CTR(unsigned char *countIn, unsigned char *input, int in_len, unsigned char *output, int *out_len, unsigned char *key, int keylen)
{
	//u256 IV256;
	u128 IV128;
	u128 w0, w1, w2, w3;
	u128 t0, t1, t2, t3;
	int g, i;
	unsigned char tempin[64] = { 0 };//  128*4/8=64
	unsigned char tempout[64] = { 0 };//  128*4/8=64
	unsigned char Subkey[2656] = { 0 };//83*32=   Subkey[83][32]
	//分组长度 不是  256bit  倍数  ，即消息长度不合格，退出
	if (in_len % BLOCKBYTE != 0) {//分组长度为  256比特  32BYTE
		printf("ERROR  消息长度不是  %d byte  倍数",BLOCKBYTE);
		return 0;
	}
	if (keylen != KEYBYTE) {
		printf("ERROR  密钥长度不是  %d byte  ",KEYBYTE);
		return 0;
	}
	Key_Schedule(key, keylen,0,Subkey);
	printSubKey(Subkey);

	//一次处理  128*4bit  64 BYTE数据
	for (g = 0; g < in_len / ParallelBYTE; g++)
	{
		tangram_256_Encrypt(countIn+ g * ParallelBYTE, tempout, Subkey);

		w0 = _mm_loadu_si128((__m128i*)(tempout + 0 * 16));
		w1 = _mm_loadu_si128((__m128i*)(tempout + 1 * 16));
		w2 = _mm_loadu_si128((__m128i*)(tempout + 2 * 16));
		w3 = _mm_loadu_si128((__m128i*)(tempout + 3 * 16));
		t0 = _mm_loadu_si128((__m128i*)(input + g * ParallelBYTE + 0 * 16));
		t1 = _mm_loadu_si128((__m128i*)(input + g * ParallelBYTE + 1 * 16));
		t2 = _mm_loadu_si128((__m128i*)(input + g * ParallelBYTE + 2 * 16));
		t3 = _mm_loadu_si128((__m128i*)(input + g * ParallelBYTE + 3 * 16));
		w0 = _mm_xor_si128(w0, t0);	
		w1 = _mm_xor_si128(w1, t1);	
		w2 = _mm_xor_si128(w2, t2);	
		w3 = _mm_xor_si128(w3, t3);	
		_mm_storeu_si128((__m128i *)(output + g * ParallelBYTE + (0 * 16)), w0);
		_mm_storeu_si128((__m128i *)(output + g * ParallelBYTE + (1 * 16)), w1);
		_mm_storeu_si128((__m128i *)(output + g * ParallelBYTE + (2 * 16)), w2);
		_mm_storeu_si128((__m128i *)(output + g * ParallelBYTE + (3 * 16)), w3);
	}
	if (in_len % ParallelBYTE != 0) {

		
		tangram_256_Encrypt(countIn+ g * ParallelBYTE, tempout, Subkey);

		w0 = _mm_loadu_si128((__m128i*)(tempout + 0 * 16));
		w1 = _mm_loadu_si128((__m128i*)(tempout + 1 * 16));
		t0 = _mm_loadu_si128((__m128i*)(input + g * ParallelBYTE + 0 * 16));
		t1 = _mm_loadu_si128((__m128i*)(input + g * ParallelBYTE + 1 * 16));
		w0 = _mm_xor_si128(w0, t0);	
		w1 = _mm_xor_si128(w1, t1);	
		_mm_storeu_si128((__m128i *)(output + g * ParallelBYTE + (0 * 16)), w0);
		_mm_storeu_si128((__m128i *)(output + g * ParallelBYTE + (1 * 16)), w1);

	}
	*out_len = in_len;

	return 0;
}

int Crypt_Dec_Block_CTR(unsigned char *countIn, unsigned char *input, int in_len, unsigned char *output, int *out_len, unsigned char *key, int keylen)
{
	u128 IV128;
	u128 w0, w1, w2, w3;
	u128 t0, t1, t2, t3;
	int g, i;
	unsigned char tempin[64] = { 0 };//  128*4/8=64
	unsigned char tempout[64] = { 0 };//  128*4/8=64
	unsigned char Subkey[2656] = { 0 };//83*32=   Subkey[83][32]
	//分组长度 不是  256bit  倍数  ，即消息长度不合格，退出
	if (in_len % BLOCKBYTE != 0) {//分组长度为  256比特  32BYTE
		printf("ERROR  消息长度不是  %d byte  倍数",BLOCKBYTE);
		return 0;
	}
	if (keylen != KEYBYTE) {
		printf("ERROR  密钥长度不是  %d byte  ",KEYBYTE);
		return 0;
	}
	Key_Schedule(key, keylen,0,Subkey);

	printSubKey(Subkey);

	//一次处理  128*4bit  64 BYTE数据
	for (g = 0; g < in_len / ParallelBYTE; g++)
	{

		
		tangram_256_Encrypt(countIn+ g * ParallelBYTE, tempout, Subkey);

		w0 = _mm_loadu_si128((__m128i*)(tempout + 0 * 16));
		w1 = _mm_loadu_si128((__m128i*)(tempout + 1 * 16));
		w2 = _mm_loadu_si128((__m128i*)(tempout + 2 * 16));
		w3 = _mm_loadu_si128((__m128i*)(tempout + 3 * 16));
		t0 = _mm_loadu_si128((__m128i*)(input + g * ParallelBYTE + 0 * 16));
		t1 = _mm_loadu_si128((__m128i*)(input + g * ParallelBYTE + 1 * 16));
		t2 = _mm_loadu_si128((__m128i*)(input + g * ParallelBYTE + 2 * 16));
		t3 = _mm_loadu_si128((__m128i*)(input + g * ParallelBYTE + 3 * 16));
		w0 = _mm_xor_si128(w0, t0);	
		w1 = _mm_xor_si128(w1, t1);	
		w2 = _mm_xor_si128(w2, t2);	
		w3 = _mm_xor_si128(w3, t3);	
		_mm_storeu_si128((__m128i *)(output + g * ParallelBYTE + (0 * 16)), w0);
		_mm_storeu_si128((__m128i *)(output + g * ParallelBYTE + (1 * 16)), w1);
		_mm_storeu_si128((__m128i *)(output + g * ParallelBYTE + (2 * 16)), w2);
		_mm_storeu_si128((__m128i *)(output + g * ParallelBYTE + (3 * 16)), w3);
	}
	if (in_len % ParallelBYTE != 0) {
		
		tangram_256_Encrypt(countIn+ g * ParallelBYTE, tempout, Subkey);

		w0 = _mm_loadu_si128((__m128i*)(tempout + 0 * 16));
		w1 = _mm_loadu_si128((__m128i*)(tempout + 1 * 16));
		t0 = _mm_loadu_si128((__m128i*)(input + g * ParallelBYTE + 0 * 16));
		t1 = _mm_loadu_si128((__m128i*)(input + g * ParallelBYTE + 1 * 16));
		w0 = _mm_xor_si128(w0, t0);	
		w1 = _mm_xor_si128(w1, t1);	
		_mm_storeu_si128((__m128i *)(output + g * ParallelBYTE + (0 * 16)), w0);
		_mm_storeu_si128((__m128i *)(output + g * ParallelBYTE + (1 * 16)), w1);

	}
	*out_len = in_len;

	return 0;
}
