﻿#include <stdio.h>
#include <memory.h>
#include <time.h>
#include <stdlib.h>
#include <malloc.h>

#include <emmintrin.h>//sse2 header file(include sse header file)  
#include <pmmintrin.h> //SSE3(include emmintrin.h)  
#include <tmmintrin.h>//SSSE3(include pmmintrin.h)  
#include <smmintrin.h>//SSE4.1(include tmmintrin.h)  
#include <nmmintrin.h>//SSE4.2(include smmintrin.h)   
#include <immintrin.h>
#include <xmmintrin.h>
#include <wmmintrin.h>
typedef unsigned char u8;
typedef unsigned int u32;
typedef unsigned long long u64;
//typedef unsigned __int64 u64;
typedef __m128i u128;
//typedef __m256i u256;
#define ROUNDNUM  82

#define KEYBYTE   32//
//#define KEYBIT   256//
#define ParallelBYTE  64//  128*4/8=64
#define BLOCKBYTE   32//256/8=32
#define ParallelOFFSETBYTE   16// 128/8=32

#if defined(_MSC_VER)
#define ALIGNED_(x) __declspec(align(x))
#else
#if defined(__GNUC__)
#define ALIGNED_(x) __attribute__((aligned(x)))
typedef unsigned long long _ULonglong;
#endif
#endif

#define ALIGNED_TYPE_(t,x) t ALIGNED_(x) // 使用Intel的SSE/AVX指令进行数据装载时，对齐数据读取会更高效
#define data_t ALIGNED_TYPE_(u8, 16)
/** @brief Tangram的ShiftRow的第1行的行移位参数 */
#define ROL64_1  1
/** @brief Tangram的ShiftRow的第2行的行移位参数 */
#define ROL64_2 8
/** @brief Tangram的ShiftRow的第3行的行移位参数 */
#define ROL64_3 41
#define rol64(x, n)   (((x) << ((int)((n) & 0x3f))) | ((x) >> ((int)((64 - ((n) & 0x3f))))) & 0xffffffffffffffff) 

void BYTETOU64(unsigned char * countIn, u64 *x) ;

void U64TOBYTE(u64 x, unsigned char * countIn) ;
void countAddU64(int num, unsigned char * countIn, unsigned char * countOut) ;
#define PRINTBLOCKTXT
void printBLOCKTXT(FILE *fp, const char* str, u8 *s, int len) ;

#define PRINTSubKeyTXT
void printSubKeyTXT(FILE *fp, u8 *Subkey);
//#define PRINTSubKey
//#define PRINTSTATE
#define PRINTBLOCK
void printStateSubkey(unsigned char *str, u64 k0, u64 k1, u64 k2, u64 k3);
void printSubKey(u8 *Subkey);
void printBLOCK(const char* str, u8 *s, int len) ;
/** @brief TANGRAM-128 的密钥状态的4个分支的8列经过S盒变换 */
#define key256_sbox(k0, k1, k2, k3)                                    \
{                                                                      \
	t1 = k0 ^ k2;                                                      \
	t2 = k0 & k1;                                                      \
	t3 = k3 ^ t2;                                                      \
	g = k2 ^ t3;                                                       \
	t5 = k1 ^ k2;                                                      \
	t6 = t1 & t3;                                                      \
	e = t5 ^ t6;                                                       \
	t8 = k1 | k3;                                                      \
	t9 = t1 ^ t8;                                                      \
	h = ~t9;                                                           \
	t11 = t5 & t9;                                                     \
	f = t3 ^ t11;                                                      \
	k0 = e;                                                            \
	k1 = f;                                                            \
	k2 = g;                                                            \
	k3 = h;                                                            \
}

/** @brief TANGRAM-128 的密钥编排的一轮4-分支Feistel变换 */
//这里没有进行feistel移位
#define key256_rol(k0, k1, k2, k3)                                     \
{                                                                      \
	t0 = rol64(k0, 7);				                               \
	t1 = rol64(k2, 17);				                               \
	k1 ^= t0;						                                   \
	k3 ^= t1; 					                                       \
}
//void tangram_256_KeySchedule(unsigned char *Seedkey, unsigned char *Subkey) ;


#define forward_round256_sbox_2block(w0, w1, w2, w3)  \
{                   \
	tmm1 =_mm_xor_si128(  w0  , w2    );	\
	tmm2 =_mm_and_si128(  w0  , w1    );	\
	tmm3 =_mm_xor_si128(  w3  , tmm2  );	\
	g    =_mm_xor_si128(  w2  , tmm3  );	\
	tmm5 =_mm_xor_si128(  w1  , w2    );	\
	tmm6 =_mm_and_si128(  tmm1, tmm3  );	\
	e    =_mm_xor_si128(  tmm5, tmm6  );	\
	tmm8 =_mm_or_si128 (  w1  , w3    );	\
	tmm9 =_mm_xor_si128(  tmm1, tmm8  );	\
	h    =_mm_xor_si128(  tmm9 , all1 );	\
	tmm11=_mm_and_si128(  tmm5, tmm9  );	\
	f    =_mm_xor_si128(  tmm3, tmm11 );	\
	w0 = e;  	\
	w1 = f; 	\
	w2 = g; 	\
	w3 = h;  	\
}
/*

*/
#define ROUND256_Encrypt(i) {\
	/*AddRoundKey（ARK）*/\
	kmm0 = _mm_set1_epi64(((__m64*)Subkey)[0+i*4]);	\
	kmm1 = _mm_set1_epi64(((__m64*)Subkey)[1+i*4]);	\
	kmm2 = _mm_set1_epi64(((__m64*)Subkey)[2+i*4]);	\
	kmm3 = _mm_set1_epi64(((__m64*)Subkey)[3+i*4]);	\
	w0 = _mm_xor_si128(w0, kmm0);	\
	w1 = _mm_xor_si128(w1, kmm1);	\
	w2 = _mm_xor_si128(w2, kmm2);	\
	w3 = _mm_xor_si128(w3, kmm3);	\
	/*SubColumn（SC）*/\
	forward_round256_sbox_2block(w0, w1, w2, w3); \
	/*ShiftRow（SR）*/\
	w1 = _mm_or_si128(_mm_slli_epi64(w1,  ROL64_1), _mm_srli_epi64(w1, 64 - ROL64_1));    \
	w2 = _mm_or_si128(_mm_slli_epi64(w2,  ROL64_2), _mm_srli_epi64(w2, 64 - ROL64_2));     \
	w3 = _mm_or_si128(_mm_slli_epi64(w3,  ROL64_3), _mm_srli_epi64(w3, 64 - ROL64_3));   \
}


#define invert_round256_sbox_2block(w0, w1, w2, w3)  \
{                   \
	tmm1 =_mm_xor_si128(  w3  , all1  );	\
	tmm2 =_mm_and_si128(  w0  , tmm1  );	\
	tmm3 =_mm_xor_si128(  w1  , tmm2  );	\
	g    =_mm_xor_si128(  w2  , tmm3  );	\
	tmm5 =_mm_xor_si128(  w0  , w2    );	\
	tmm6 =_mm_and_si128(  tmm1, tmm3  );	\
	f    =_mm_xor_si128(  tmm5, tmm6  );	\
	tmm8 =_mm_xor_si128(  w0  , tmm1  );	\
	tmm9 =_mm_and_si128(  tmm3, tmm5  );	\
	e    =_mm_xor_si128(  tmm8, tmm9  );	\
	tmm11=_mm_and_si128(  f   , e      );	\
	h    =_mm_xor_si128(  tmm3, tmm11 );	\
	w0 = e;  	\
	w1 = f; 	\
	w2 = g; 	\
	w3 = h;  	\
}
#define ROUND256_Decrypt(i) {\
	/*AddRoundKey（ARK）*/\
	kmm0 = _mm_set1_epi64(((__m64*)Subkey)[0+i*4]);	\
	kmm1 = _mm_set1_epi64(((__m64*)Subkey)[1+i*4]);	\
	kmm2 = _mm_set1_epi64(((__m64*)Subkey)[2+i*4]);	\
	kmm3 = _mm_set1_epi64(((__m64*)Subkey)[3+i*4]);	\
	w0 = _mm_xor_si128(w0, kmm0);	\
	w1 = _mm_xor_si128(w1, kmm1);	\
	w2 = _mm_xor_si128(w2, kmm2);	\
	w3 = _mm_xor_si128(w3, kmm3);	\
	/*ShiftRow（SR）*/\
	w1 = _mm_or_si128(_mm_srli_epi64(w1,  ROL64_1), _mm_slli_epi64(w1, 64 - ROL64_1));    \
	w2 = _mm_or_si128(_mm_srli_epi64(w2,  ROL64_2), _mm_slli_epi64(w2, 64 - ROL64_2));     \
	w3 = _mm_or_si128(_mm_srli_epi64(w3,  ROL64_3), _mm_slli_epi64(w3, 64 - ROL64_3));   \
	/*SubColumn（SC）*/\
	invert_round256_sbox_2block(w0, w1, w2, w3); \
}


void tangram_256_Encrypt(unsigned char *plain, unsigned char *cipher, unsigned char *Subkey);
int Key_Schedule(unsigned char * seedkey,int keylen,int direction,unsigned char * subkey);
void tangram_256_Decrypt(unsigned char *cipher, unsigned char *plain, unsigned char *Subkey);

int Crypt_Enc_Block(unsigned char *input, int in_len, unsigned char *output, int *out_len, unsigned char *key, int keylen);
int Crypt_Dec_Block(unsigned char *input, int in_len, unsigned char *output, int *out_len, unsigned char *key, int keylen);

void tangram_256_Encrypt_Round(unsigned char *plain, unsigned char *cipher, unsigned char *Subkey,int cryptround);

int Crypt_Enc_Block_Round(unsigned char *input, int in_len, unsigned char *output, int *out_len, unsigned char *key, int keylen,int cryptround);
int Crypt_Enc_Block_CTR(unsigned char *countIV, unsigned char *input, int in_len, unsigned char *output, int *out_len, unsigned char *key, int keylen);

int Crypt_Dec_Block_CTR(unsigned char *countIV, unsigned char *input, int in_len, unsigned char *output, int *out_len, unsigned char *key, int keylen);
#define  loopNum  2000
