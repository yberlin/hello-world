﻿#include"128128SSE.h"
/** @brief 轮常量数组，这里我们事先用函数 rc() 生成这个数组，通过查表使用轮常量*/
u32 RC[44] =
{
	0x1,0x2,0x4,0x8,0x10,0x21,0x3,0x6,0xc,0x18,0x31,0x22,0x5,0xa,0x14,0x29,0x13,0x27,
	0xf,0x1e,0x3d,0x3a,0x34,0x28,0x11,0x23,0x7,0xe,0x1c,0x39,0x32,0x24,0x9,0x12,0x25,
	0xb,0x16,0x2d,0x1b,0x37,0x2e,0x1d,0x3b,0x36,
};
int Key_Schedule(unsigned char * seedkey,int keylen,int direction,unsigned char * subkey){
	
	int i;
	u32 k0, k1, k2, k3;
	u32 t0, t1, t2, t3, t4, t5, t6, t7, t8, t9, t10, t11;
	u32 e, f, g, h;
	u32 tmp;
	
	if (keylen != KEYBYTE) {
		printf("ERROR  密钥长度不是  %d byte  ",KEYBYTE);
		return 0;
	}
	k0 = ((u32*)seedkey)[0];
	k1 = ((u32*)seedkey)[1];
	k2 = ((u32*)seedkey)[2];
	k3 = ((u32*)seedkey)[3];
	for (i = 0; i < ROUNDNUM; i++) {
		//Subkey
		*(u32*)subkey = k0;
		subkey += 4;
		*(u32*)subkey = k1;
		subkey += 4;
		*(u32*)subkey = k2;
		subkey += 4;
		*(u32*)subkey = k3;
		subkey += 4;
		//Sbox
		key128_sbox(k0, k1, k2, k3);
		key128_rol(k0, k1, k2, k3);
		k1 ^= RC[i];
		//feistel移位
		tmp = k0;
		k0 = k1; k1 = k2; k2 = k3; k3 = tmp;
	}
	//Subkey
	*(u32*)subkey = k0;
	subkey += 4;
	*(u32*)subkey = k1;
	subkey += 4;
	*(u32*)subkey = k2;
	subkey += 4;
	*(u32*)subkey = k3;
	subkey += 4;
}


void printBLOCK(const char* str, u8 *s, int len) {
#ifdef PRINTBLOCK
	int i, j;
	printf("%-9s   :\n", str);
	for (i = 0; i < len; i++) {
		printf("%02x,", s[i]);
		if (i % 16 == 15)
			printf("\n");
	}
	printf("\n");
#endif
}

void printBLOCKTXT(FILE *fp, const char* str, u8 *s, int len) {
#ifdef PRINTBLOCKTXT
	int i, j;
	fprintf(fp, "%-9s   :\n", str);
	for (i = 0; i < len; i++) {
		fprintf(fp, "%02x,", s[i]);
		if (i % 16 == 15)
			fprintf(fp, "\n");
	}
	fprintf(fp, "\n");
#endif
}

void printSubKeyTXT(FILE *fp, u8 *Subkey) {
#ifdef PRINTSubKeyTXT
	int i, j;
	fprintf(fp, "SubKey:\n");
	for (j = 0; j < 45; j++) {
		fprintf(fp, "%-3d ：", j);
		for (i = 0; i < 16; i++) {
			fprintf(fp, "%02x", Subkey[j * 16 + i]);
		}
		fprintf(fp, "\n");
	}
#endif
}
void printSubKey(u8 *Subkey) {
#ifdef PRINTSubKey
	int i, j;
	for (j = 0; j < 45; j++) {
		printf("%d ：\n", j);
		for (i = 0; i < 16; i++) {
			printf("%02x", Subkey[j * 16 + i]);
		}
		printf("\n");
	}
#endif
}
void tangram_128_Encrypt(unsigned char *plain, unsigned char *cipher, unsigned char *Subkey)
{
	u128 w0, w1, w2, w3;
	u128 tmm0, tmm1, tmm2, tmm3, tmm4, tmm5, tmm6, tmm7, tmm8, tmm9, tmm10, tmm11;
	u128 e, f, g, h;
	int i = 0;
	u128 kmm0, kmm1, kmm2, kmm3;

	u128 xmm01, xmm13, xmm02, xmm23, xmm45, xmm57, xmm46, xmm67;
	u128 all1 = _mm_set1_epi32(0xffffffff);

	xmm01 = _mm_loadu_si128((__m128i*)(plain + 0 * 16));
	xmm23 = _mm_loadu_si128((__m128i*)(plain + 1 * 16));
	xmm45 = _mm_loadu_si128((__m128i*)(plain + 2 * 16));
	xmm67 = _mm_loadu_si128((__m128i*)(plain + 3 * 16));
	xmm02 = _mm_unpacklo_epi32(xmm01, xmm23);
	xmm13 = _mm_unpackhi_epi32(xmm01, xmm23);
	xmm46 = _mm_unpacklo_epi32(xmm45, xmm67);
	xmm57 = _mm_unpackhi_epi32(xmm45, xmm67);
	w0 = _mm_unpacklo_epi32(xmm02, xmm46);
	w1 = _mm_unpackhi_epi32(xmm02, xmm46);
	w2 = _mm_unpacklo_epi32(xmm13, xmm57);
	w3 = _mm_unpackhi_epi32(xmm13, xmm57);

	for (i = 0; i < ROUNDNUM; i++) {
		//	printState(i,w0, w1, w2, w3);
		ROUND128_Encrypt(i);
	}
	//printState(i,w0, w1, w2, w3);
	//最后一轮

	kmm0 = _mm_set1_epi32(((u32*)Subkey)[0 + i * 4]);	\
		kmm1 = _mm_set1_epi32(((u32*)Subkey)[1 + i * 4]);	\
		kmm2 = _mm_set1_epi32(((u32*)Subkey)[2 + i * 4]);	\
		kmm3 = _mm_set1_epi32(((u32*)Subkey)[3 + i * 4]);	\

		w0 = _mm_xor_si128(w0, kmm0);	\
		w1 = _mm_xor_si128(w1, kmm1);	\
		w2 = _mm_xor_si128(w2, kmm2);	\
		w3 = _mm_xor_si128(w3, kmm3);	\

		//	printState(i, w0, w1, w2, w3);

		xmm02 = _mm_unpacklo_epi32(w0, w1);
	xmm13 = _mm_unpackhi_epi32(w0, w1);
	xmm46 = _mm_unpacklo_epi32(w2, w3);
	xmm57 = _mm_unpackhi_epi32(w2, w3);
	w0 = _mm_unpacklo_epi64(xmm02, xmm46);
	w2 = _mm_unpackhi_epi64(xmm02, xmm46);
	w1 = _mm_unpacklo_epi64(xmm13, xmm57);
	w3 = _mm_unpackhi_epi64(xmm13, xmm57);

	//	printState(i, w0, w1, w2, w3);
	_mm_storeu_si128((__m128i *)(cipher + (0 * 16)), w0);
	_mm_storeu_si128((__m128i *)(cipher + (1 * 16)), w1);
	_mm_storeu_si128((__m128i *)(cipher + (2 * 16)), w2);
	_mm_storeu_si128((__m128i *)(cipher + (3 * 16)), w3);
}

void tangram_128_Decrypt(unsigned char *cipher, unsigned char *plain, unsigned char *Subkey)
{
	u128 w0, w1, w2, w3;
	u128 tmm0, tmm1, tmm2, tmm3, tmm4, tmm5, tmm6, tmm7, tmm8, tmm9, tmm10, tmm11;
	u128 e, f, g, h;
	int i = 0;
	u128 kmm0, kmm1, kmm2, kmm3;

	u128 xmm01, xmm13, xmm02, xmm23, xmm45, xmm57, xmm46, xmm67;
	u128 all1 = _mm_set1_epi32(0xffffffff);
	xmm01 = _mm_loadu_si128((__m128i*)(cipher + 0 * 16));
	xmm23 = _mm_loadu_si128((__m128i*)(cipher + 1 * 16));
	xmm45 = _mm_loadu_si128((__m128i*)(cipher + 2 * 16));
	xmm67 = _mm_loadu_si128((__m128i*)(cipher + 3 * 16));
	//	printState(0,xmm01, xmm23, xmm45, xmm67);
	xmm02 = _mm_unpacklo_epi32(xmm01, xmm23);
	xmm13 = _mm_unpackhi_epi32(xmm01, xmm23);
	xmm46 = _mm_unpacklo_epi32(xmm45, xmm67);
	xmm57 = _mm_unpackhi_epi32(xmm45, xmm67);
	w0 = _mm_unpacklo_epi32(xmm02, xmm46);
	w1 = _mm_unpackhi_epi32(xmm02, xmm46);
	w2 = _mm_unpacklo_epi32(xmm13, xmm57);
	w3 = _mm_unpackhi_epi32(xmm13, xmm57);
	for (i = ROUNDNUM; i > 0; i--) {
		ROUND128_Decrypt(i);
	}
	//最后一轮
	kmm0 = _mm_set1_epi32(((u32*)Subkey)[0 + i * 4]);	\
		kmm1 = _mm_set1_epi32(((u32*)Subkey)[1 + i * 4]);	\
		kmm2 = _mm_set1_epi32(((u32*)Subkey)[2 + i * 4]);	\
		kmm3 = _mm_set1_epi32(((u32*)Subkey)[3 + i * 4]);	\
		w0 = _mm_xor_si128(w0, kmm0);	\
		w1 = _mm_xor_si128(w1, kmm1);	\
		w2 = _mm_xor_si128(w2, kmm2);	\
		w3 = _mm_xor_si128(w3, kmm3);	\

		//		printState(i, w0, w1, w2, w3);

		xmm02 = _mm_unpacklo_epi32(w0, w1);
	xmm13 = _mm_unpackhi_epi32(w0, w1);
	xmm46 = _mm_unpacklo_epi32(w2, w3);
	xmm57 = _mm_unpackhi_epi32(w2, w3);
	w0 = _mm_unpacklo_epi64(xmm02, xmm46);
	w2 = _mm_unpackhi_epi64(xmm02, xmm46);
	w1 = _mm_unpacklo_epi64(xmm13, xmm57);
	w3 = _mm_unpackhi_epi64(xmm13, xmm57);
	//	printState(i, w0, w1, w2, w3);
	_mm_storeu_si128((__m128i *)(plain + (0 * 16)), w0);
	_mm_storeu_si128((__m128i *)(plain + (1 * 16)), w1);
	_mm_storeu_si128((__m128i *)(plain + (2 * 16)), w2);
	_mm_storeu_si128((__m128i *)(plain + (3 * 16)), w3);
}

void FinalParallelIn(int in_len, unsigned char *input, unsigned char* tempin) {
	u128 t1, t2, t3;

	switch ((in_len % ParallelBYTE) / BLOCKBYTE) {


	case 1:
		t1 = _mm_loadu_si128((__m128i*)(input));
		_mm_storeu_si128((__m128i *)(tempin), t1);
		break;

	case 2:
		t1 = _mm_loadu_si128((__m128i*)(input));
		_mm_storeu_si128((__m128i *)(tempin), t1);
		t2 = _mm_loadu_si128((__m128i*)(input + ParallelOFFSETBYTE));
		_mm_storeu_si128((__m128i *)(tempin + ParallelOFFSETBYTE), t2);
		break;
	case 3:
		t1 = _mm_loadu_si128((__m128i*)(input));
		_mm_storeu_si128((__m128i *)(tempin), t1);
		t2 = _mm_loadu_si128((__m128i*)(input + ParallelOFFSETBYTE));
		_mm_storeu_si128((__m128i *)(tempin + ParallelOFFSETBYTE), t2);
		t3 = _mm_loadu_si128((__m128i*)(input + ParallelOFFSETBYTE * 2));
		_mm_storeu_si128((__m128i *)(tempin + ParallelOFFSETBYTE * 2), t3);
		break;
	}
}
void FinalParallelOut(int in_len, unsigned char *output, unsigned char* tempout) {
	u128 t1, t2, t3;
	switch ((in_len % ParallelBYTE) / BLOCKBYTE) {
	case 1:
		t1 = _mm_loadu_si128((__m128i*)(tempout));
		_mm_storeu_si128((__m128i *)(output), t1);
		break;

	case 2:
		t1 = _mm_loadu_si128((__m128i*)(tempout));
		_mm_storeu_si128((__m128i *)(output), t1);
		t2 = _mm_loadu_si128((__m128i*)(tempout + ParallelOFFSETBYTE));
		_mm_storeu_si128((__m128i *)(output + ParallelOFFSETBYTE), t2);
		break;
	case 3:
		t1 = _mm_loadu_si128((__m128i*)(tempout));

		_mm_storeu_si128((__m128i *)(output), t1);
		t2 = _mm_loadu_si128((__m128i*)(tempout + ParallelOFFSETBYTE));
		_mm_storeu_si128((__m128i *)(output + ParallelOFFSETBYTE), t2);
		t3 = _mm_loadu_si128((__m128i*)(tempout + ParallelOFFSETBYTE * 2));
		_mm_storeu_si128((__m128i *)(output + ParallelOFFSETBYTE * 2), t3);
		break;
	}
}
int Crypt_Enc_Block(unsigned char *input, int in_len, unsigned char *output, int *out_len, unsigned char *key, int keylen)
{
	int i;
	u128 t1, t2, t3;
	int g;
	unsigned char tempin[64] = { 0 };//  128*4/8=64
	unsigned char tempout[64] = { 0 };//  
	unsigned char Subkey[720];
	//分组长度 不是  128bit  倍数  ，即消息长度不合格，退出
	if (in_len % BLOCKBYTE != 0) {
		printf("ERROR  消息长度不是  %d byte  倍数",BLOCKBYTE);
		return 0;
	}
	if (keylen != KEYBYTE) {
		printf("ERROR  密钥长度不是  %d byte  ",KEYBYTE);
		return 0;
	}
	//tangram_128_KeySchedule(key, Subkey);
	Key_Schedule(key, keylen,0,Subkey);
	//	printSubKey(Subkey);
	for (g = 0; g < (in_len / ParallelBYTE); g++)
	{
		tangram_128_Encrypt(input + g * ParallelBYTE, output + g * ParallelBYTE, Subkey);
	}
	if (in_len % ParallelBYTE != 0) {

		FinalParallelIn(in_len, input + g * ParallelBYTE, tempin);
		tangram_128_Encrypt(tempin, tempout, Subkey);
		FinalParallelOut(in_len, output + g * ParallelBYTE, tempout);

	}
	*out_len = in_len;
	return 0;
}

int Crypt_Dec_Block(unsigned char *input, int in_len, unsigned char *output, int *out_len, unsigned char *key, int keylen)
{
	int i;
	u128 t1, t2, t3;
	int g;
	unsigned char tempin[64] = { 0 };//  128*4/8=64
	unsigned char tempout[64] = { 0 };//  128*4/8=64
	unsigned char Subkey[720];
	//分组长度 不是  128bit  倍数  ，即消息长度不合格，退出
	if (in_len % BLOCKBYTE != 0) {
		printf("ERROR  消息长度不是  %d byte  倍数",BLOCKBYTE);
		return 0;
	}
	if (keylen != KEYBYTE) {
		printf("ERROR  密钥长度不是  %d byte  ",KEYBYTE);
		return 0;
	}
	
	Key_Schedule(key, keylen,0,Subkey);
	//tangram_128_KeySchedule(key, Subkey);
	//一次处理4个分组长度
	for (g = 0; g < in_len / ParallelBYTE; g++)
	{
		tangram_128_Decrypt(input + g * ParallelBYTE, output + g * ParallelBYTE, Subkey);
	}
	//最后一个并行处理，分组长度必须为 128bit/16Byte  的倍数，并且in_len % 64不等于0，即表示最后一个并行处理 1~3个分组
	if (in_len % ParallelBYTE != 0) {

		FinalParallelIn(in_len, input + g * ParallelBYTE, tempin);
		tangram_128_Decrypt(tempin, tempout, Subkey);
		FinalParallelOut(in_len, output + g * ParallelBYTE, tempout);
	
	}
	*out_len = in_len;

	return 0;
}
void tangram_128_Encrypt_Round(unsigned char *plain, unsigned char *cipher, unsigned char *Subkey, int cryptround)
{

	u128 w0, w1, w2, w3;
	u128 tmm0, tmm1, tmm2, tmm3, tmm4, tmm5, tmm6, tmm7, tmm8, tmm9, tmm10, tmm11;
	u128 e, f, g, h;
	int i = 0;
	u128 kmm0, kmm1, kmm2, kmm3;

	u128 xmm01, xmm13, xmm02, xmm23, xmm45, xmm57, xmm46, xmm67;
	u128 all1 = _mm_set1_epi32(0xffffffff);

	xmm01 = _mm_loadu_si128((__m128i*)(plain + 0 * 16));
	xmm23 = _mm_loadu_si128((__m128i*)(plain + 1 * 16));
	xmm45 = _mm_loadu_si128((__m128i*)(plain + 2 * 16));
	xmm67 = _mm_loadu_si128((__m128i*)(plain + 3 * 16));
	xmm02 = _mm_unpacklo_epi32(xmm01, xmm23);
	xmm13 = _mm_unpackhi_epi32(xmm01, xmm23);
	xmm46 = _mm_unpacklo_epi32(xmm45, xmm67);
	xmm57 = _mm_unpackhi_epi32(xmm45, xmm67);
	w0 = _mm_unpacklo_epi32(xmm02, xmm46);
	w1 = _mm_unpackhi_epi32(xmm02, xmm46);
	w2 = _mm_unpacklo_epi32(xmm13, xmm57);
	w3 = _mm_unpackhi_epi32(xmm13, xmm57);

	for (i = 0; i < cryptround; i++) {
		//	printState(i,w0, w1, w2, w3);
		ROUND128_Encrypt(i);
	}
	//printState(i,w0, w1, w2, w3);
	//最后一轮

	kmm0 = _mm_set1_epi32(((u32*)Subkey)[0 + i * 4]);	\
		kmm1 = _mm_set1_epi32(((u32*)Subkey)[1 + i * 4]);	\
		kmm2 = _mm_set1_epi32(((u32*)Subkey)[2 + i * 4]);	\
		kmm3 = _mm_set1_epi32(((u32*)Subkey)[3 + i * 4]);	\

		w0 = _mm_xor_si128(w0, kmm0);	\
		w1 = _mm_xor_si128(w1, kmm1);	\
		w2 = _mm_xor_si128(w2, kmm2);	\
		w3 = _mm_xor_si128(w3, kmm3);	\

		//	printState(i, w0, w1, w2, w3);

		xmm02 = _mm_unpacklo_epi32(w0, w1);
	xmm13 = _mm_unpackhi_epi32(w0, w1);
	xmm46 = _mm_unpacklo_epi32(w2, w3);
	xmm57 = _mm_unpackhi_epi32(w2, w3);
	w0 = _mm_unpacklo_epi64(xmm02, xmm46);
	w2 = _mm_unpackhi_epi64(xmm02, xmm46);
	w1 = _mm_unpacklo_epi64(xmm13, xmm57);
	w3 = _mm_unpackhi_epi64(xmm13, xmm57);

	//	printState(i, w0, w1, w2, w3);
	_mm_storeu_si128((__m128i *)(cipher + (0 * 16)), w0);
	_mm_storeu_si128((__m128i *)(cipher + (1 * 16)), w1);
	_mm_storeu_si128((__m128i *)(cipher + (2 * 16)), w2);
	_mm_storeu_si128((__m128i *)(cipher + (3 * 16)), w3);
}
int Crypt_Enc_Block_Round(unsigned char *input, int in_len, unsigned char *output, int *out_len, unsigned char *key, int keylen, int cryptround)
{
	int i;
	u128 t1, t2, t3;
	int g;
	unsigned char tempin[64] = { 0 };//  128*4/8=64
	unsigned char tempout[64] = { 0 };//  
	unsigned char Subkey[720];
	//分组长度 不是  128bit  倍数  ，即消息长度不合格，退出
	if (in_len % BLOCKBYTE != 0) {
		printf("ERROR  消息长度不是  %d byte  倍数",BLOCKBYTE);
		return 0;
	}
	if (keylen != KEYBYTE) {
		printf("ERROR  密钥长度不是  %d byte  ",KEYBYTE);
		return 0;
	}
	
	Key_Schedule(key, keylen,0,Subkey);
	//tangram_128_KeySchedule(key, Subkey);

	//	printSubKey(Subkey);
	for (g = 0; g < in_len / ParallelBYTE; g++)
	{
		tangram_128_Encrypt_Round(input + g * ParallelBYTE, output + g * ParallelBYTE, Subkey, cryptround);
	}
	if (in_len % ParallelBYTE != 0) {

		FinalParallelIn(in_len, input + g * ParallelBYTE, tempin);
		tangram_128_Encrypt_Round(tempin, tempout, Subkey, cryptround);
		FinalParallelOut(in_len, output + g * ParallelBYTE, tempout);

	}
	*out_len = in_len;

	return 0;

}

int Crypt_Enc_Block_CTR(unsigned char *countIn, unsigned char *input, int in_len, unsigned char *output, int *out_len, unsigned char *key, int keylen)
{

	u128 IV128;
	int i;
	int g;
	unsigned char tempin[64] = { 0 };//  128*4/8=64
	unsigned char tempout[64] = { 0 };//  
	unsigned char Subkey[720];
	u128 w0, w1, w2, w3;
	u128 t0, t1, t2, t3;
	//分组长度 不是  128bit  倍数  ，即消息长度不合格，退出
	if (in_len % BLOCKBYTE != 0) {
		printf("ERROR  消息长度不是  %d byte  倍数",BLOCKBYTE);
		return 0;
	}
	if (keylen != KEYBYTE) {
		printf("ERROR  密钥长度不是  %d byte  ",KEYBYTE);
		return 0;
	}
	
	Key_Schedule(key, keylen,0,Subkey);
	//tangram_128_KeySchedule(key, Subkey);
	//	printSubKey(Subkey);
	for (g = 0; g < in_len / ParallelBYTE; g++)
	{
		tangram_128_Encrypt(countIn+ g * ParallelBYTE, tempout, Subkey);	

		w0 = _mm_loadu_si128((__m128i*)(tempout + 0 * 16));
		w1 = _mm_loadu_si128((__m128i*)(tempout + 1 * 16));
		w2 = _mm_loadu_si128((__m128i*)(tempout + 2 * 16));
		w3 = _mm_loadu_si128((__m128i*)(tempout + 3 * 16));
		t0 = _mm_loadu_si128((__m128i*)(input + g * ParallelBYTE + 0 * 16));
		t1 = _mm_loadu_si128((__m128i*)(input + g * ParallelBYTE + 1 * 16));
		t2 = _mm_loadu_si128((__m128i*)(input + g * ParallelBYTE + 2 * 16));
		t3 = _mm_loadu_si128((__m128i*)(input + g * ParallelBYTE + 3 * 16));
		w0 = _mm_xor_si128(w0, t0);	
		w1 = _mm_xor_si128(w1, t1);	
		w2 = _mm_xor_si128(w2, t2);	
		w3 = _mm_xor_si128(w3, t3);	
		_mm_storeu_si128((__m128i *)(output + g * ParallelBYTE + (0 * 16)), w0);
		_mm_storeu_si128((__m128i *)(output + g * ParallelBYTE + (1 * 16)), w1);
		_mm_storeu_si128((__m128i *)(output + g * ParallelBYTE + (2 * 16)), w2);
		_mm_storeu_si128((__m128i *)(output + g * ParallelBYTE + (3 * 16)), w3);
	}
	if (in_len % ParallelBYTE != 0) {
		FinalParallelIn(in_len, input + g * ParallelBYTE, tempin);
		tangram_128_Encrypt(countIn+ g * ParallelBYTE, tempout, Subkey);

		w0 = _mm_loadu_si128((__m128i*)(tempout + 0 * 16));
		w1 = _mm_loadu_si128((__m128i*)(tempout + 1 * 16));
		w2 = _mm_loadu_si128((__m128i*)(tempout + 2 * 16));
		w3 = _mm_loadu_si128((__m128i*)(tempout + 3 * 16));
		t0 = _mm_loadu_si128((__m128i*)(tempin + 0 * 16));
		t1 = _mm_loadu_si128((__m128i*)(tempin + 1 * 16));
		t2 = _mm_loadu_si128((__m128i*)(tempin + 2 * 16));
		t3 = _mm_loadu_si128((__m128i*)(tempin + 3 * 16));
		w0 = _mm_xor_si128(w0, t0);
		w1 = _mm_xor_si128(w1, t1);
		w2 = _mm_xor_si128(w2, t2);
		w3 = _mm_xor_si128(w3, t3);
		_mm_storeu_si128((__m128i *)(tempout + (0 * 16)), w0);
		_mm_storeu_si128((__m128i *)(tempout + (1 * 16)), w1);
		_mm_storeu_si128((__m128i *)(tempout + (2 * 16)), w2);
		_mm_storeu_si128((__m128i *)(tempout + (3 * 16)), w3);

		FinalParallelOut(in_len, output + g * ParallelBYTE, tempout);

	}
	*out_len = in_len;

	return 0;
}

int Crypt_Dec_Block_CTR(unsigned char *countIn, unsigned char *input, int in_len, unsigned char *output, int *out_len, unsigned char *key, int keylen)
{
	u128 w0, w1, w2, w3;
	u128 t0, t1, t2, t3;
	u128 IV128;
	int i;
	int g;
	unsigned char tempin[64] = { 0 };//  128*4/8=64
	unsigned char tempout[64] = { 0 };//  128*4/8=64
	unsigned char Subkey[720];
	//分组长度 不是  128bit  倍数  ，即消息长度不合格，退出
	if (in_len % BLOCKBYTE != 0) {
		printf("ERROR  消息长度不是  %d byte  倍数",BLOCKBYTE);
		return 0;
	}
	if (keylen != KEYBYTE) {
		printf("ERROR  密钥长度不是  %d byte  ",KEYBYTE);
		return 0;
	}
	
	Key_Schedule(key, keylen,0,Subkey);
	//tangram_128_KeySchedule(key, Subkey);
	//一次处理4个分组长度
	for (g = 0; g < in_len / ParallelBYTE; g++)
	{
		tangram_128_Encrypt(countIn+ g * ParallelBYTE, tempout, Subkey);	

		w0 = _mm_loadu_si128((__m128i*)(tempout + 0 * 16));
		w1 = _mm_loadu_si128((__m128i*)(tempout + 1 * 16));
		w2 = _mm_loadu_si128((__m128i*)(tempout + 2 * 16));
		w3 = _mm_loadu_si128((__m128i*)(tempout + 3 * 16));
		t0 = _mm_loadu_si128((__m128i*)(input + g * ParallelBYTE + 0 * 16));
		t1 = _mm_loadu_si128((__m128i*)(input + g * ParallelBYTE + 1 * 16));
		t2 = _mm_loadu_si128((__m128i*)(input + g * ParallelBYTE + 2 * 16));
		t3 = _mm_loadu_si128((__m128i*)(input + g * ParallelBYTE + 3 * 16));
		w0 = _mm_xor_si128(w0, t0);
		w1 = _mm_xor_si128(w1, t1);
		w2 = _mm_xor_si128(w2, t2);
		w3 = _mm_xor_si128(w3, t3);
		_mm_storeu_si128((__m128i *)(output + g * ParallelBYTE + (0 * 16)), w0);
		_mm_storeu_si128((__m128i *)(output + g * ParallelBYTE + (1 * 16)), w1);
		_mm_storeu_si128((__m128i *)(output + g * ParallelBYTE + (2 * 16)), w2);
		_mm_storeu_si128((__m128i *)(output + g * ParallelBYTE + (3 * 16)), w3);
	}
	//最后一个并行处理，分组长度必须为 128bit/16Byte  的倍数，并且in_len % 64不等于0，即表示最后一个并行处理 1~3个分组
	if (in_len % ParallelBYTE != 0) {

		FinalParallelIn(in_len, input + g * ParallelBYTE, tempin);
		
		tangram_128_Encrypt(countIn+ g * ParallelBYTE, tempout, Subkey);	

		w0 = _mm_loadu_si128((__m128i*)(tempout + 0 * 16));
		w1 = _mm_loadu_si128((__m128i*)(tempout + 1 * 16));
		w2 = _mm_loadu_si128((__m128i*)(tempout + 2 * 16));
		w3 = _mm_loadu_si128((__m128i*)(tempout + 3 * 16));
		t0 = _mm_loadu_si128((__m128i*)(tempin + 0 * 16));
		t1 = _mm_loadu_si128((__m128i*)(tempin + 1 * 16));
		t2 = _mm_loadu_si128((__m128i*)(tempin + 2 * 16));
		t3 = _mm_loadu_si128((__m128i*)(tempin + 3 * 16));
		w0 = _mm_xor_si128(w0, t0);
		w1 = _mm_xor_si128(w1, t1);
		w2 = _mm_xor_si128(w2, t2);
		w3 = _mm_xor_si128(w3, t3);
		_mm_storeu_si128((__m128i *)(tempout + (0 * 16)), w0);
		_mm_storeu_si128((__m128i *)(tempout + (1 * 16)), w1);
		_mm_storeu_si128((__m128i *)(tempout + (2 * 16)), w2);
		_mm_storeu_si128((__m128i *)(tempout + (3 * 16)), w3);

		FinalParallelOut(in_len, output + g * ParallelBYTE, tempout);


	}
	*out_len = in_len;

	return 0;
}
