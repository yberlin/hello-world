#ifndef CONFIG_H
#define CONFIG_H

#ifndef MODE
#define MODE 3
#endif

//#define USE_AES
//#define RANDOMIZED_SIGNING
//#define USE_RDPMC
//#define SERIALIZE_RDC
//#define DBENCH

#endif
