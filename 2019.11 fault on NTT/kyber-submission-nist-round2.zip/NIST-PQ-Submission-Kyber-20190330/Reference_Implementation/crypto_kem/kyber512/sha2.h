#ifndef SHA_2_H
#define SHA_2_H

void sha512(unsigned char *out,const unsigned char *in,unsigned long long inlen);

void sha256(unsigned char *out,const unsigned char *in,unsigned long long inlen);

#endif
